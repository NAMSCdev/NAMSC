#pragma once

#include <QDataStream>

namespace NovelLib
{
    enum class SerializationID
    {
        ActionAudioSetMusic                      = 0, 
        ActionAudioSetSounds                     = 1, 
        ActionStatVisibility                = 2, 
        ActionStatSetValue                  = 3, 
        ActionEffectBlur                    = 4, 
        ActionEffectDistort                 = 5, 
        ActionEffectGlow                    = 6, 
        ActionFilterBlur                    = 7, 
        ActionFilterBrightness              = 8, 
        ActionFilterDilation                = 9, 
        ActionFilterErosion                 = 10,
        ActionFilterHue                     = 11,
        ActionFilterNegative                = 12,
        ActionFilterSaturation              = 13,
        ActionLive2DAnim                    = 14,
        ActionLive2DModelChange             = 15,
        ActionSceneryObjectAnimColor        = 16,
        ActionSceneryObjectAnimMove         = 17,
        ActionSceneryObjectAnimRotate       = 18,
        ActionSceneryObjectAnimScale        = 19,
        ActionSceneryObjectAnimFade       = 20,
        ActionCharacterSetVoice          = 21,
        ActionSceneryObjectSetImage      = 22,
        ActionSetBackground                 = 23,
        SceneryBackgroundAssetImage         = 25,
        SceneryObjectPartAssetImage         = 26,
        StatString                          = 27,
        StatLongLong                        = 28,
        StatDouble                          = 29,
        Sentence                            = 30,
        Translation                         = 31,
        Voice                               = 32,
        AnimatorSceneryObjectColor          = 34,
        AnimatorSceneryObjectMove           = 35,
        AnimatorSceneryObjectRotate         = 36,
        AnimatorSceneryObjectScale          = 37,
        Character                           = 38,
        Scenery                             = 39,
        EventRenPyScript                    = 40,
        EventChoice                         = 41,
        EventEndIf                          = 42,
        EventIf                             = 43,
        EventInput                          = 44,
        EventJump                           = 45,
        EventNarrate                        = 46,
        EventDialogue                          = 47,
        EventWait                           = 48
    };
}

/// Serialization loading
template<typename T>
concept SerializableLoad = requires(QDataStream& dataStream, T& t)
{
    t.serializableLoad(dataStream);
};

template<SerializableLoad T>
QDataStream& operator>>(QDataStream& dataStream, T& t)
{
    t.serializableLoad(dataStream);
    return dataStream;
}

/// Serialization saving
template<typename T>
concept SerializableSave = requires(QDataStream& dataStream, T& t)
{
    t.serializableSave(dataStream);
};

template<SerializableSave T>
QDataStream& operator<<(QDataStream& dataStream, const T& t)
{
    t.serializableSave(dataStream);
    return dataStream;
}