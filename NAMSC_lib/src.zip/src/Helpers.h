#pragma once

#include <QPointer>
#include <QString>
#include <QList>
#include <QException>
#include "Exceptions.h"

namespace NovelLib
{
    /// \return The element or nullptr if it was not found
    /// \exception Error Couldn't find the element named `name` in the `vector` container
    //template<class Type>
    //Type* findInArray(const QString& name, const QList<Type>& vector)
    //{
    //    auto element = std::find(vector.cbegin(), vector.cend(), name);
    //    if (element == vector.cend())
    //    {
    //        qCritical() << typeid(Type).name() << " with a name \"" << name + "\" could not be found!";
    //        return nullptr;
    //    }
    //    return &(*element);
    //}

	/// \return The element or nullptr if it was not found
	/// \exception Error Couldn't find the element with an ID `ID` in the `vector` container
	//template<class Type>
	//Type* findInArray(const int ID, const QList<Type>& vector)
	//{
	//	auto element = std::find(vector.cbegin(), vector.cend(), ID);
	//	if (element == vector.cend())
	//	{
	//		qCritical() << typeid(Type).name() << " with an ID " << ID + " could not be found!";
	//		return nullptr;
	//	}
	//	return &(*element);
	//}

	bool catchExceptions(std::function<void(bool bComprehensive)> errorChecker, bool bComprehensive)
	{
		try
		{
			errorChecker(bComprehensive);
			return false;
		}
		catch (QException& ex)
		{
			qCritical() << NovelLib::ErrorType::General << ex.what();
			return true;
		}
		catch (std::exception& ex)
		{
			qCritical() << ex.what();
			return true;
		}
		catch (...)
		{
			return true;
		}
		return false;
	}
}