﻿#pragma once

namespace NovelLib
{
	#define LOG_FILENAME "log.txt"
	enum ErrorType : unsigned int
	{
		General,
		NameDuplicate,
		AssetAnimFileMissing,
		AssetAnimInvalid,
		AssetAnimLoad,
		AssetAnimMissing,
		AssetImageFileMissing,
		AssetImageInvalid,
		AssetImageLoad,
		AssetImageMissing,
		CharacterMissing,
		CharacterInvalid,
		VoiceInvalid,
		VoiceMissing,
		SceneryObjectInvalid,
		SceneryObjectMissing,
		StatInvalid,
		StatMissing
	};
}