#include "Novel/Event/EventChoice.h"

#include "Novel/Data/Scene.h"

EventChoice::EventChoice(Scene* const parentScene) 
	: Event(parentScene)
{
}

EventChoice::EventChoice(Scene* const parentScene, const QString label, const Translation& menuText, const QList<Choice>& choices, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), menuText_(menuText), choices(choices)
{
	checkForErrors(true);
}

EventChoice& EventChoice::operator=(const EventChoice& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_    = obj.onRun_;
	menuText_ = obj.menuText_;
	choices   = obj.choices;

	return *this;
}

bool EventChoice::operator==(const EventChoice& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)     &&
			menuText_ == obj.menuText_ &&
			choices   == obj.choices;
}

bool EventChoice::checkForErrors(bool bComprehensive = false) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError || menuText_.checkForErrors(bComprehensive))
	{
		qDebug() << "Error occurred in an EventChoice of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	for (const Choice& choice : choices)
		if (choice.checkForErrors(bComprehensive))
			{
				qDebug() << "Error occurred in an EventChoice of Scene \"" << parentScene_->name << "\" Event " << getIndex();
				return true;
			}
	;

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an EventChoice of Scene \"" << parentScene_->name << "\" Event " << getIndex();
	//	return true;
	//}

	return false;
}

void EventChoice::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);

	dataStream >> menuText_;

	uint choicesSize;
	dataStream >> choicesSize;
	for (uint i = 0u; i != choicesSize; ++i)
	{
		Choice choice;
		dataStream >> choice;
		choices.push_back(choice));
	}
	checkForErrors();
}

void EventChoice::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);

	dataStream << menuText_ << choices.size();
	for (const Choice& choice : choices)
		dataStream << choice;
}