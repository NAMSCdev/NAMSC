#pragma once
#include "Novel/Event/EventChoice.h"
#include "Novel/Event/EventEndIf.h"
#include "Novel/Event/EventIf.h"
#include "Novel/Event/EventInput.h"
#include "Novel/Event/EventJump.h"
#include "Novel/Event/EventNarrate.h"
#include "Novel/Event/EventDialogue.h"
#include "Novel/Event/EventWait.h"

//#include "Novel/Event/EventRenPyScript.h"
