#include "Novel/Event/EventDialogue.h"

#include "Novel/Data/Scene.h"

EventDialogue::EventDialogue(Scene* const parentScene)
	: Event(parentScene)
{
}

EventDialogue::EventDialogue(Scene* const parentScene, const QString& label, const QList<Sentence>& sentences, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), sentences(sentences)
{
	checkForErrors(true);
}

EventDialogue& EventDialogue::operator=(const EventDialogue& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_    = obj.onRun_;
	sentences = obj.sentences;

	return *this;
}

bool EventDialogue::operator==(const EventDialogue& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj) &&
			sentences == obj.sentences;
}

bool EventDialogue::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventDialogue of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	for (const Sentence& sentence : sentences)
		if (sentence.checkForErrors(bComprehensive))
	{
		qDebug() << "Error occurred in an EventDialogue of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an EventDialogue of Scene \"" << parentScene_->name << "\" Event " << getIndex();
	//	return true;
	//}

	return false;
}

void EventDialogue::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	uint sentencesSize = 0;
	dataStream >> sentencesSize;

	for (unsigned i = 0; i != sentencesSize; ++i)
	{
		Sentence sentence;
		dataStream >> sentence;
		sentences.push_back(std::move(sentence));
	}

	checkForErrors();
}

void EventDialogue::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << sentences.size();

	for (const Sentence& sentence: sentences)
		dataStream << sentence;
}