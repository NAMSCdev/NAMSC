#pragma once
#include "Novel/Event/EventsAll.h"

/// CorrectsJump
class EventVisitorCorrectJumps final : public EventVisitor
{
public:
	EventVisitorCorrectJumps(int oldID, int newID) : oldID(oldID), newID(newID) {}

	virtual void visitEventChoice(EventChoice *e) override 
	{ 
		for (Choice& choice : e->choices)
			if (choice.jumpSceneID == oldID)
				choice.jumpSceneID = newID;
	}
	virtual void visitEventInput(EventInput *e) override   
	{ 
		if (e->bLogicalExpression); }
	virtual void visitEventJump(EventJump *e) override     { changeID(e); }

private:
	int oldID = -1,
		newID = -1;
};