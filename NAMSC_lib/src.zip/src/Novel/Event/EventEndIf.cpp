#include "Novel/Event/EventEndIf.h"

#include "Novel/Data/Scene.h"

EventEndIf::EventEndIf(Scene* const parentScene)
	: Event(parentScene)
{
}

EventEndIf::EventEndIf(Scene* const parentScene, const QString& label, Event* const partner, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), partner_(partner)
{
	checkForErrors(true);
}

EventEndIf& EventEndIf::operator=(const EventEndIf& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_   = obj.onRun_;
	partner_ = obj.partner_;

	return *this;
}

bool EventEndIf::operator==(const EventEndIf& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)  &&
			partner_ == obj.partner_;
}

bool EventEndIf::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventEndIf of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (getIndex() <= partner_->getIndex())
		{
			qCritical() << NovelLib::ErrorType::General << "EventEndIf (" << getIndex() << ") has not a greater index that its partner EventIf (" << partner_->getIndex() << ')';
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an EventEndIf of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	return false;
}


void EventEndIf::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	uint index;
	dataStream >> index;
	partner_ = &(parentScene_->events[index]);
	checkForErrors();
}

void EventEndIf::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << partner_->getIndex();
}
