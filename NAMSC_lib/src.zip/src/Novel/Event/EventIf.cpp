#include "Novel/Event/EventIf.h"

#include "Novel/Data/Scene.h"

EventIf::EventIf(Scene* const parentScene)
	: Event(parentScene)
{
}

EventIf::EventIf(Scene* const parentScene, const QString& label, const QString& condition, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), condition(condition)
{
	checkForErrors(true);
}

EventIf& EventIf::operator=(const EventIf& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_    = obj.onRun_;
	condition = obj.condition;

	return *this;
}

bool EventIf::operator==(const EventIf& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)    &&
			condition == obj.condition;
}

bool EventIf::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventIf of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//todo check condition
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an EventIf of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	return false;
}

void EventIf::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	dataStream >> condition;
	checkForErrors();
}

void EventIf::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << condition;
}