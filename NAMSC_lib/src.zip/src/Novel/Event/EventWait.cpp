#include "Novel/Event/EventWait.h"

#include "Novel/Data/Scene.h"

EventWait::EventWait(Scene* const parentScene)
	: Event(parentScene)
{
}

EventWait::EventWait(Scene* const parentScene, const QString& label, const uint waitTime, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), waitTime(waitTime)
{

}

EventWait& EventWait::operator=(const EventWait& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_   = obj.onRun_;
	waitTime = obj.waitTime;

	return *this;
}

bool EventWait::operator==(const EventWait& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)  &&
			waitTime == obj.waitTime;
}

bool EventWait::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventWait of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an EventWait of Scene \"" << parentScene_->name << "\" Event " << getIndex();
	//	return true;
	//}

	return false;
}

void EventWait::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	dataStream >> waitTime;
}

void EventWait::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << waitTime;
}