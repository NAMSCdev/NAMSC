#include "Novel/Event/EventInput.h"

#include "Novel/Data/Scene.h"

EventInput::EventInput(Scene* const parentScene)
	: Event(parentScene)
{
	checkForErrors(true);
}

EventInput::EventInput(Scene* const parentScene, const QString& label, const uint minCharacters, const QString& regex, const QString& inputStatName, const bool bDigitsOnly, const long long digitsOnly_min, const long long digitsOnly_max, const bool bLogicalExpression, const QString& logicalExpression, const int logicalExpression_tries, const int logicalExpression_failureJumpSceneID, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), minCharacters(minCharacters), regex(regex), inputStatName_(inputStatName), bDigitsOnly(bDigitsOnly), digitsOnly_min(digitsOnly_min), digitsOnly_max(digitsOnly_max), bLogicalExpression(bLogicalExpression), logicalExpression(logicalExpression), logicalExpression_tries(logicalExpression_tries), logicalExpression_failureJumpSceneID(logicalExpression_failureJumpSceneID)
{
}

EventInput& EventInput::operator=(const EventInput& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onSuccess_              = obj.onSuccess_;
	onFailure_              = obj.onFailure_;
	onReject_               = obj.onReject_;
	minCharacters           = obj.minCharacters;
	regex                   = obj.regex;
	inputStatName_          = obj.inputStatName_;
	bDigitsOnly             = obj.bDigitsOnly;
	digitsOnly_min          = obj.digitsOnly_min;
	digitsOnly_max          = obj.digitsOnly_max;
	bLogicalExpression      = obj.bLogicalExpression;
	logicalExpression       = obj.logicalExpression;
	logicalExpression_tries = obj.logicalExpression_tries;
	logicalExpression_failureJumpSceneID = obj.logicalExpression_failureJumpSceneID;

	return *this;
}

bool EventInput::operator==(const EventInput& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)                                                          &&
			minCharacters           == obj.minCharacters                                    &&
			regex                   == obj.regex                                            &&
			inputStatName_          == obj.inputStatName_                                   &&
			bDigitsOnly             == obj.bDigitsOnly                                      &&
			digitsOnly_min          == obj.digitsOnly_min                                   &&
			digitsOnly_max          == obj.digitsOnly_max                                   &&
			bLogicalExpression      == obj.bLogicalExpression                               &&
			logicalExpression       == obj.logicalExpression                                &&
			logicalExpression_tries == obj.logicalExpression_tries                          &&
			logicalExpression_failureJumpSceneID == obj.logicalExpression_failureJumpSceneID;
}

bool EventInput::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventInput of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//todo check if `regex` is valid
		//todo check if `logicalExpression` is valid
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an EventInput of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	return false;
}

void EventInput::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	dataStream >> minCharacters >> regex >> bDigitsOnly >> digitsOnly_min >> digitsOnly_max >> bLogicalExpression >> logicalExpression >> logicalExpression_tries >> logicalExpression_failureJumpSceneID >> inputStatName_;
	checkForErrors();
}

void EventInput::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << minCharacters << regex << bDigitsOnly << digitsOnly_min << digitsOnly_max << bLogicalExpression << logicalExpression << logicalExpression_tries << logicalExpression_failureJumpSceneID << inputStatName_;
}