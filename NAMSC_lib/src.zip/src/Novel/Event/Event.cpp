#include "Novel/Event/Event.h"

#include "Novel/Action/ActionsAll.h"
#include "Novel/Data/Scene.h"

Event& Event::operator=(const Event& obj)
{
	if (this == &obj) return *this;

	label   = obj.label;
	actions = obj.actions;

	return *this;
}

bool Event::operator==(const Event& obj) const
{
	if (this == &obj) return true;

	return	label   == obj.label  &&
			actions == obj.actions;
}

bool Event::checkForErrors(bool bComprehensive) const
{
	for (const Action& action : actions)
		if (action.checkForErrors(bComprehensive))
			return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (bComprehensive)
			for (auto it = parentScene_->events.cbegin(); it != parentScene_->events.cend(); ++it)
				if ((it->label == label) && (&(*it) != this))
				{
					qCritical() << NovelLib::ErrorType::NameDuplicate << "Duplicate labels \"" << label << "\" for Scene " << getIndex() << " and Scene " << it->getIndex();

					return true;
				}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
		return true;

	return false;
}

uint Event::getIndex() const
{
	const QList<Event>& events = parentScene_->events;
	return std::find(events.cbegin(), events.cend(), *this) - events.cbegin();
}

void Event::run()
{
	ensureResourcesAreLoaded();
	for (Action& action : actions)
		action.run();
}

void Event::end()
{
	for (Action& action : actions)
		action.end();
}

void Event::update()
{
	for (Action& action : actions)
		action.update();
}

void Event::syncWithSave()
{
	for (Action& action : actions)
		action.syncWithSave();
}

void Event::ensureResourcesAreLoaded()
{
	for (Action& action : actions)
		action.ensureResourcesAreLoaded();
}

void Event::serializableLoad(QDataStream& dataStream)
{
	dataStream >> label;

	uint actionsSize;
	dataStream >> actionsSize;
	for (uint i = 0u; i != actionsSize; ++i)
	{
		NovelLib::SerializationID type;
		dataStream >> type;

		Action* action;
		switch (type)
		{
		case NovelLib::SerializationID::ActionAudioSetMusic:
			action = new ActionAudioSetMusic(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionAudioSetSounds:
			action = new ActionAudioSetSounds(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionStatSetValue:
			action = new ActionStatSetValue(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectAnimColor:
			action = new ActionSceneryObjectAnimColor(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectAnimMove:
			action = new ActionSceneryObjectAnimMove(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectAnimRotate:
			action = new ActionSceneryObjectAnimRotate(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectAnimScale:
			action = new ActionSceneryObjectAnimScale(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectAnimFade:
			action = new ActionSceneryObjectAnimFade(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionCharacterSetVoice:
			action = new ActionCharacterSetVoice(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSceneryObjectSetImage:
			action = new ActionSceneryObjectSetImage(this, this->parentScene_);
			break;
		case NovelLib::SerializationID::ActionSetBackground:
			action = new ActionSetBackground(this, this->parentScene_);
			break;
		default:
			qCritical() << NovelLib::ErrorType::General << "Invalid Action's Type " << static_cast<int>(type);
			break;
		}
		dataStream >> *action;
		actions.emplace_back(action);
	}
}

void Event::serializableSave(QDataStream& dataStream) const
{
	dataStream << getType() << label;
	for (const Action& action : actions)
		dataStream << action;
}