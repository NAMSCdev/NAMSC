#include "Novel/Event/EventJump.h"

#include "Novel/Data/Scene.h"

EventJump::EventJump(Scene* const parentScene)
	: Event(parentScene)
{
}

EventJump::EventJump(Scene* const parentScene, const QString& label, const int jumpSceneID, const QString& condition, const QList<Action>* actions = nullptr)
	: Event(parentScene, label, actions), jumpSceneID(jumpSceneID), condition(condition)
{
	checkForErrors(true);
}

EventJump& EventJump::operator=(const EventJump& obj)
{
	if (this == &obj) return *this;

	Event::operator=(obj);
	onRun_      = obj.onRun_;
	jumpSceneID = obj.jumpSceneID;
	condition   = obj.condition;

	return *this;
}

bool EventJump::operator==(const EventJump& obj) const
{
	if (this == &obj) return true;

	return 	Event::operator==(obj)         &&
			jumpSceneID == obj.jumpSceneID &&
			condition   == obj.condition;
}

bool EventJump::checkForErrors(bool bComprehensive) const
{
	bool bError = Event::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an EventJump of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (jumpSceneID == -1)
		{
			qCritical() << NovelLib::ErrorType::General << "EventJump is missing a jumpSceneID";
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an EventJump of Scene \"" << parentScene_->name << "\" Event " << getIndex();
		return true;
	}

	return false;
}

void EventJump::serializableLoad(QDataStream& dataStream)
{
	Event::serializableLoad(dataStream);
	dataStream >> jumpSceneID >> condition;
	checkForErrors();
}

void EventJump::serializableSave(QDataStream& dataStream) const
{
	Event::serializableSave(dataStream);
	dataStream << jumpSceneID << condition;
}