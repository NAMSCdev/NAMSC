#pragma once
#include "Novel/Event/Event.h"

class Scene;

/// Redirects the flow to an another Scene
class EventJump final : public Event
{
public:
	EventJump(Scene* const parentScene) noexcept;
	/// \exception One of the Actions contains an Error or the `jumpSceneID` points to a deleted Scene or the `condition` is not structured properly
	EventJump(Scene* const parentScene, const QString& label, const int jumpSceneID, const QString& condition, const QList<Action>* actions = nullptr);
	EventJump(const EventJump& obj) = delete;
	EventJump& operator=(const EventJump& obj) noexcept;
	bool operator==(const EventJump& obj) const noexcept;
	bool operator!=(const EventJump& obj) const noexcept { return !(*this == obj); }

	/// \exception Error invalid Action in `actions` / invalid `regex` / invalid `Stat` / invalid `logicalExpression`
	/// \return Whether an Error has occurred
	/// \todo implement this
	bool checkForErrors(bool bComprehensive = false) const override;

	void run() override;

	/// Sets a function pointer that is called (if not nullptr) after the EventJump's `void run()` allowing for data read
	void setOnRunListener(std::function<void(int jumpSceneID, QString condition)> onRun) { onRun_ = onRun; }

	void acceptVisitor(EventVisitor* visitor) override { visitor->visitEventJump(this); }

	int	jumpSceneID   = -1;

	/// A jump might contain a logical expression, so the jump happens only if the `condition` is met
	QString condition = "";

private:
	/// Needed for Serialization, to know the class of an object before the loading performed
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::EventJump; }

	/// A function pointer that is called (if not nullptr) after the EventJump's `void run()` allowing for data read
	std::function<void(int jumpSceneID, QString condition)> onRun_ = nullptr;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};