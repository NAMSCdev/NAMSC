#include <QFile>
#include <QMediaPlayer>

#include "Novel/Action/Audio/ActionAudioSetMusic.h"
#include "Novel/Action/Audio/ActionAudioSetSounds.h"
#include "Novel/Action/Visual/ActionCharacterSetVoice.h"
#include "Novel/Action/Visual/ActionSceneryObjectSetImage.h"
#include "Novel/Action/Stat/ActionStat.h"
#include "Novel/Action/Stat/ActionStatSetValue.h"
#include "Novel/Data/Novel.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectColor.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectMove.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectRotate.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectScale.h"
#include "Novel/Data/Scene.h"

bool ActionCharacter::checkForErrors(bool bComprehensive) const
{
	bool bError = Action::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (characterName == "")
		{
			qCritical() << "No Character assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is a Character with this name in the Novel's container 
		if (Novel::getInstance().findCharacter(characterName_) == nullptr)
		{
			qCritical() << "Character \"" + characterName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
	};
	
	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}


bool ActionSceneryObject::checkForErrors(bool bComprehensive) const
{
	bool bError = Action::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (sceneryObjectName_ == "")
		{
			qCritical() << "No SceneryObject assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is a SceneryObject with this name in the Novel's container 
		if (Novel::getInstance().findSceneryObject(sceneryObjectName_) == nullptr)
		{
			qCritical() << "SceneryObject \"" + sceneryObjectName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
	};
	
	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}


bool ActionSceneryObjectSetImage::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObject::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (assetImageName_ == "")
		{
			qCritical() << "No AssetImage assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetImage with this name in the AssetManager's container 
		AssetImage* assetImage = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
		if (assetImage == nullptr)
		{
			qCritical() << "AssetImage \"" + assetImageName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}

		//Check if the AssetImage doesn't have any Errors
		if (bComprehensive)
			return assetImage->checkForErrors(bComprehensive);
	};
	
	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool AnimatorSceneryObjectColor::checkForErrors(bool bComprehensive) const
{
	bool bError = AnimatorSceneryObjectInterface::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (assetAnimName_ == "")
		{
			qCritical() << "No AssetImage assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetAnim with this name in the AssetManager's container 
		AssetAnim<AnimNodeDouble4D> * assetAnim = AssetManager::getInstance().findAssetAnimColor(assetAnimName_);
		if (assetAnim == nullptr)
		{
			qCritical() << "AssetImage \"" + assetAnimName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
		//Check if the AssetAnim doesn't have any Errors
		if (bComprehensive)
			return assetAnim->checkForErrors(bComprehensive);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool AnimatorSceneryObjectMove::checkForErrors(bool bComprehensive = false) const
{
	bool bError = AnimatorSceneryObjectInterface::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (assetAnimName_ == "")
		{
			qCritical() << "No AssetImage assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetAnim with this name in the AssetManager's container 
		AssetAnim<AnimNodeDouble2D>* assetAnim = AssetManager::getInstance().findAssetAnimMove(assetAnimName_);
		if (assetAnim == nullptr)
		{
			qCritical() << "AssetImage \"" + assetAnimName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
		//Check if the AssetAnim doesn't have any Errors
		if (bComprehensive)
			return assetAnim->checkForErrors(bComprehensive);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool AnimatorSceneryObjectRotate::checkForErrors(bool bComprehensive = false) const
{
	bool bError = AnimatorSceneryObjectInterface::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (assetAnimName_ == "")
		{
			qCritical() << "No AssetImage assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetAnim with this name in the AssetManager's container 
		AssetAnim<AnimNodeDouble1D>* assetAnim = AssetManager::getInstance().findAssetAnimRotate(assetAnimName_);
		if (assetAnim == nullptr)
		{
			qCritical() << "AssetImage \"" + assetAnimName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
		//Check if the AssetAnim doesn't have any Errors
		if (bComprehensive)
			return assetAnim->checkForErrors(bComprehensive);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool AnimatorSceneryObjectScale::checkForErrors(bool bComprehensive = false) const
{
	bool bError = AnimatorSceneryObjectInterface::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (assetAnimName_ == "")
		{
			qCritical() << "No AssetImage assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetAnim with this name in the AssetManager's container 
		AssetAnim<AnimNodeDouble2D>* assetAnim = AssetManager::getInstance().findAssetAnimScale(assetAnimName_);
		if (assetAnim == nullptr)
		{
			qCritical() << "AssetImage \"" + assetAnimName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
		//Check if the AssetAnim doesn't have any Errors
		if (bComprehensive)
			return assetAnim->checkForErrors(bComprehensive);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool AnimatorSceneryObjectInterface::checkForErrors(bool bComprehensive) const
{
	bool bError = AnimatorInterface::checkForErrors(bComprehensive);
	if (bError)
		return true;

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (sceneryObjectName_ == "")
		{
			qCritical() << NovelLib::ErrorType::ResourceMissing << "No SceneryObject assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is a SceneryObject with this name in the Novel's container 
		if (Novel::getInstance().findSceneryObject(sceneryObjectName_) == nullptr)
		{
			qCritical() << NovelLib::ErrorType::ResourceNotFound << "SceneryObject \"" << sceneryObjectName_ << "\" could not be found. Definition file might be corrupted";
			return true;
		}
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool Character::checkForErrors(bool bComprehensive) const
{
	bool bError = SceneryObject::checkForErrors(bComprehensive);
	if (bError)
		return true;
	
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if the name is undefined
		if (defaultVoiceName_ == "")
		{
			qCritical() << "No Voice assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is a Voice with this name in the Novel's container 
		if (Novel::getInstance().findVoice(defaultVoiceName_) == nullptr)
		{
			qCritical() << "Voice \"" + defaultVoiceName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}
	};
	
	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool MusicPlaylist::checkForErrors(bool bComprehensive) const
{
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		for (const QString& fileLocation : audioFilesPaths_)
		{
			//Check if name is undefined
			if (fileLocation == "")
			{
				qCritical() << "No File assigned. Was it deleted and not replaced?";
				return true;
			}

			//Check if the File is still there in the User's filesystem
			if (!QFile::exists(fileLocation))
			{
				qCritical() << "Could not find a file \"" + fileLocation + "\"";
				return true;
			}

			QMediaPlayer player;
			//TODO: check if this will ensure the format is right
			player.setSource(fileLocation);
		}
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool SceneryObject::checkForErrors(bool bComprehensive) const
{
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if name is undefined
		if (assetImageName_ == "")
		{
			qCritical() << "No File assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if there is an AssetImage with this name in the AssetManager's container 
		AssetImage* assetImage = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
		if (assetImage == nullptr)
		{
			qCritical() << "AssetImage \"" + assetImageName_ + "\" could not be found. Definition file might be corrupted";
			return true;
		}

		//Check if the AssetImage doesn't have any Errors
		if (bComprehensive)
			return assetImage->checkForErrors(bComprehensive);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool Sound::checkForErrors(bool bComprehensive) const
{
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//Check if filename is undefined
		if (soundFile_ == "")
		{
			qCritical() << "No File assigned. Was it deleted and not replaced?";
			return true;
		}

		//Check if the File is still there in the User's filesystem
		if (!QFile::exists(soundFile_))
		{
			qCritical() << "Could not find a file \"" + soundFile_ + "\"";
			return true;
		}

		QMediaPlayer player;
		//TODO: check if this will ensure the format is right
		player.setSource(soundFile_);
	};

	return NovelLib::catchExceptions(errorChecker, bComprehensive);
}

bool Scene::checkForErrors(bool bComprehensive = false) const
{
	for (const Event& event : events_)
		event.checkForErrors(bComprehensive);
}

bool Event::checkForErrors(bool bComprehensive = false) const
{
	for (const Action& action : actions_)
		action.checkForErrors(bComprehensive);
}

bool ActionStatSetValue::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionStat::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionStatSetValue";
		return true;
	}
	//todo: check expression
	//todo: check if it 

	return false;
}
