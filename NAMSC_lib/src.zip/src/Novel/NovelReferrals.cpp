//#include "Novel/Data/Novel.h"

#include "Novel/Action/Visual/ActionCharacter.h"
#include "Novel/Action/Visual/ActionCharacterSetVoice.h"
#include "Novel/Action/Visual/ActionSceneryObject.h"
#include "Novel/Action/Stat/ActionStat.h"
#include "Novel/Data/Chapter.h"
#include "Novel/Data/Text/Sentence.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"

//Code that contains references to Novel from structures that are within it and this behaviour is potentially dangerous

ActionSceneryObject::ActionSceneryObject(const QString& sceneryObjectName) :
	sceneryObjectName_(sceneryObjectName))
{
	sceneryObject_ = Novel::getInstance().findSceneryObject(sceneryObjectName);
}

AnimatorSceneryObjectInterface::AnimatorSceneryObjectInterface(uint startDelay, double speed, int timesPlayed, const QString& assetAnimName_, const QString& sceneryObjectName) :
	AnimatorInterface(startDelay, speed, timesPlayed, assetAnimName_)), sceneryObjectName_(sceneryObjectName))
{
	sceneryObject_ = Novel::getInstance().findSceneryObject(sceneryObjectName);
}

void AnimatorSceneryObjectInterface::serializableLoad(QDataStream& dataStream)
{
	AnimatorInterface::serializableLoad(dataStream);
	dataStream >> sceneryObjectName_;

	sceneryObject_ = Novel::getInstance().findSceneryObject(sceneryObjectName_);
}

Sentence::Sentence(Translation&& content, const QString& voiceName_, uint cpsOverwrite, bool bEndWithInput, double waitBeforeContinueTime) :
	content_(content), voiceName_(voiceName_), cpsOverwrite_(cpsOverwrite), bEndWithInput_(bEndWithInput), waitBeforeContinueTime_(waitBeforeContinueTime)
{
	voice_ = Novel::getInstance().findVoice(voiceName_);
}

void Novel::createNew(uint slot)
{
    QFile save(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/NAMSC/" + QString::number(slot) + ".sav");
    QDataStream dataStream(&save);

    Novel::getInstance().;
}

void Novel::load(uint slot)
{
    QFile save(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/NAMSC/" + QString::number(slot) + ".sav");
    QDataStream dataStream(&save);
}

void Chapter::serializableLoad(QDataStream& dataStream)
{
	dataStream >> name;
	QString parentName;
	dataStream >> parentName;

	Novel::getInstance().
	if (parent_)
		parent_->name = parentName;
}


Character::Character(const QString& defaultVoiceName) :
	defaultVoiceName_(defaultVoiceName)
{
	defaultVoice_ = Novel::getInstance().findVoice(defaultVoiceName);
}

void NovelSettings::defaultLanguageChange(const QString& newLanguage)
{

}