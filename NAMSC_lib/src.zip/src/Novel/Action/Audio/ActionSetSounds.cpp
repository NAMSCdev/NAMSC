#include "Novel/Action/Audio/ActionAudioSetSounds.h"

#include "Novel/Data/Scene.h"

ActionAudioSetSounds::ActionAudioSetSounds(Event* const parentEvent, Scene* const parentScene)
	: ActionAudio(parentEvent, parentScene)
{
}

ActionAudioSetSounds::ActionAudioSetSounds(Event* const parentEvent, Scene* const parentScene, const AudioSettings& audioSettings, const QList<SoundEffect>& sounds)
	: ActionAudio(parentEvent, parentScene, audioSettings), sounds(sounds)
{
	checkForErrors(true);
}

ActionAudioSetSounds& ActionAudioSetSounds::operator=(const ActionAudioSetSounds& obj)
{
	if (this == &obj) return *this;

	ActionAudio::operator=(obj);
	onRun_ = obj.onRun_;
	sounds = obj.sounds;

	return *this;
}

bool ActionAudioSetSounds::operator==(const ActionAudioSetSounds& obj) const
{
	if (this == &obj) return true;

	return	ActionAudio::operator==(obj) &&
			sounds == obj.sounds;
}

bool ActionAudioSetSounds::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionAudio::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionAudioSetSounds of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	for (const SoundEffect& sound : sounds)
		if (sound.checkForErrors(bComprehensive))
		{
			qDebug() << "Error occurred in an ActionAudioSetSounds of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
			return true;
		}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionAudioSetSounds of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionAudioSetSounds::ensureResourcesAreLoaded()
{
	for (Sound& sound : sounds)
		sound.load();
}


void ActionAudioSetSounds::serializableLoad(QDataStream& dataStream)
{
	ActionAudio::serializableLoad(dataStream);
	uint soundsSize;
	dataStream >> soundsSize;
	for (uint i = 0; i != soundsSize; ++i)
	{
		SoundEffect sound;
		dataStream >> sound;
		sounds.push_back(std::move(sound));
	}
	checkForErrors();
}

void ActionAudioSetSounds::serializableSave(QDataStream& dataStream) const
{
	ActionAudio::serializableSave(dataStream);
	dataStream << sounds.size();
	for (const Sound& sound : sounds)
		dataStream << sound;
}