#pragma once
#include "Novel/Action/Audio/ActionAudio.h"

#include "Novel/Data/Audio/MusicPlaylist.h"

export class ActionVisitorCorrectMusicPlaylist;

/// Overwrites current `sounds` in the Scenery, which contains Sounds queued to be played after `startDelay` milliseconds have passed
export class ActionAudioSetMusic final : public ActionAudio
{
	friend ActionVisitorCorrectMusicPlaylist;
public:
	ActionAudioSetMusic(Event* const parentEvent, Scene* const parentScene) noexcept;
	/// \exception Error Couldn't find/read the Song files
	ActionAudioSetMusic(Event* const parentEvent, Scene* const parentScene, const AudioSettings& audioSettings, const MusicPlaylist& playlist);
	ActionAudioSetMusic(const ActionAudioSetMusic& obj) = delete;
	ActionAudioSetMusic& operator=(const ActionAudioSetMusic& obj) noexcept;
	bool operator==(const ActionAudioSetMusic& obj) const noexcept;
	bool operator!=(const ActionAudioSetMusic& obj) const noexcept { return !(*this == obj); }

	/// \exception Error Paths in `musicPlaylist_.audioFilesPaths_` are invalid / some Songs cannot be read (whatever the reason)
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

	void run() override;

	/// Sets a function pointer that is called (if not nullptr) after the ActionAudioSetMusic's `void run()` allowing for data read
	void setOnRunListener(std::function<void(const MusicPlaylist* musicPlaylist)> onRun) { onRun_ = onRun; }

	void setMusicPlaylist(const MusicPlaylist& musicPlaylist) { musicPlaylist_ = musicPlaylist; }
	MusicPlaylist&       getMusicPlaylist()                   { return musicPlaylist_; }
	const MusicPlaylist& getMusicPlaylist() const             { return musicPlaylist_; }

	void acceptVisitor(ActionVisitor* visitor) override       { visitor->visitActionAudioSetMusic(this); }

private:
	MusicPlaylist musicPlaylist_;

	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::ActionAudioSetMusic; }

	/// A function pointer that is called (if not nullptr) after the ActionAudioSetMusic's `void run()` allowing for data read
	std::function<void(const MusicPlaylist* musicPlaylist)> onRun_ = nullptr;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};