#include "Novel/Action/Audio/ActionAudioSetMusic.h"

#include "Novel/Data/Scene.h"

ActionAudioSetMusic::ActionAudioSetMusic(Event* const parentEvent, Scene* const parentScene)
	: ActionAudio(parentEvent, parentScene)
{
}

ActionAudioSetMusic::ActionAudioSetMusic(Event* const parentEvent, Scene* const parentScene, const AudioSettings& audioSettings, const MusicPlaylist& musicPlaylist)
	: ActionAudio(parentEvent, parentScene, audioSettings), musicPlaylist_(musicPlaylist)
{
	checkForErrors(true);
}

ActionAudioSetMusic& ActionAudioSetMusic::operator=(const ActionAudioSetMusic& obj)
{
	if (this == &obj) return *this;

	ActionAudio::operator=(obj);
	onRun_         = obj.onRun_;
	musicPlaylist_ = obj.musicPlaylist_;

	return *this;
}

bool ActionAudioSetMusic::operator==(const ActionAudioSetMusic& obj) const
{
	if (this == &obj) return true;

	return	ActionAudio::operator==(obj)        && 
			musicPlaylist_ == obj.musicPlaylist_;
}

bool ActionAudioSetMusic::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionAudio::checkForErrors(bComprehensive);
	if (bError || musicPlaylist_.checkForErrors(bComprehensive))
	{
		qDebug() << "Error occurred in an ActionAudioSetMusic::checkForErrors of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionAudioSetMusic of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionAudioSetMusic::serializableLoad(QDataStream& dataStream)
{
	ActionAudio::serializableLoad(dataStream);
	dataStream >> musicPlaylist_;
	checkForErrors();
}

void ActionAudioSetMusic::serializableSave(QDataStream& dataStream) const
{
	ActionAudio::serializableSave(dataStream);
	dataStream << musicPlaylist_;
}