#include "Novel/Action/Audio/ActionAudio.h"

#include "Novel/Data/Scene.h"

ActionAudio::ActionAudio(Event* const parentEvent, Scene* const parentScene)
	: Action(parentEvent, parentScene)
{
}

ActionAudio::ActionAudio(Event* const parentEvent, Scene* const parentScene, const AudioSettings& audioSettings)
	: Action(parentEvent, parentScene), audioSettings_(audioSettings)
{
	//checkForErrors(true);
}

ActionAudio& ActionAudio::operator=(const ActionAudio& obj)
{
	if (this == &obj) return *this;

	Action::operator=(obj);
	audioSettings_ = obj.audioSettings_;

	return *this;
}

bool ActionAudio::operator==(const ActionAudio& obj) const
{
	if (this == &obj) return true;

	return	Action::operator==(obj)             &&
			audioSettings_ == obj.audioSettings_;
}

bool ActionAudio::checkForErrors(bool bComprehensive) const
{
	bool bError = Action::checkForErrors(bComprehensive);
	if (bError)
	{
		//qDebug() << "Error occurred in an ActionAudio of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}
	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionAudio of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}
	return false;
}

void ActionAudio::serializableLoad(QDataStream& dataStream)
{
	Action::serializableLoad(dataStream);
	dataStream >> audioSettings_;
}

void ActionAudio::serializableSave(QDataStream& dataStream) const
{
	Action::serializableSave(dataStream);
	dataStream << audioSettings_;
}
