#include "Novel/Action/Stat/ActionStatSetValue.h"
#include "Novel/Data/Save/NovelState.h"

void ActionStatSetValue::run()
{
	ActionStat::run();	
	if (stat_ == nullptr)
		syncWithSave();

	//todo: evaluator magic here
	//stat_->setValueFromString(expression);

	onRun_(stat_, expression);
}