#include "Novel/Action/Action.h"

#include "Novel/Data/Scene.h"

Action::Action(Event* const parentEvent, Scene* const parentScene)
	: parentEvent_(parentEvent), parentScene_(parentScene)
{
}

Action::~Action() = default;

Action& Action::operator=(const Action& obj)
{
	if (this == &obj) return *this;

	return *this;
}

bool Action::operator==(const Action& obj) const
{
	return true;
}

bool Action::checkForErrors(bool bComprehensive) const
{
	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an Action of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void Action::serializableLoad(QDataStream& dataStream)
{
}

void Action::serializableSave(QDataStream& dataStream) const
{
	dataStream << getType();
}