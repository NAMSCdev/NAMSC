#include "Novel/Action/Visitor/ActionVisitorCorrectAsset.h"

#include "Novel/Data/Scene.h"

ActionVisitorCorrectAssetBase::ActionVisitorCorrectAssetBase(const QString& oldAssetName, const QString& newAssetName) noexcept
	: oldAssetName_(oldAssetName), newAssetName_(newAssetName) {}

ActionVisitorCorrectAssetAnimColor::ActionVisitorCorrectAssetAnimColor(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectAssetAnimMove::ActionVisitorCorrectAssetAnimMove(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectAssetAnimRotate::ActionVisitorCorrectAssetAnimRotate(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectMusicPlaylist::ActionVisitorCorrectMusicPlaylist(const QString& oldAssetName, const QString& newAssetName)noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectSounds::ActionVisitorCorrectSounds(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectBackgroundAssetImage::ActionVisitorCorrectBackgroundAssetImage(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}

ActionVisitorCorrectSceneryObjectAssetImage::ActionVisitorCorrectSceneryObjectAssetImage(const QString& oldAssetName, const QString& newAssetName) noexcept
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName) {}


void ActionVisitorCorrectAssetAnimColor::visitActionSceneryObjectAnimColor(ActionSceneryObjectAnimColor* action)
{
	if (action->assetAnim_->name == oldAssetName_)
	{
		action->assetAnim_->unload();
		action->assetAnim_ = nullptr;
		action->assetAnim_ = AssetManager::getInstance().findAssetAnimColor(newAssetName_);
		if (action->assetAnim_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Color AssetAnim \"" << newAssetName_ << "\" could not be found. Asset replacement failed";
	}
}

void ActionVisitorCorrectAssetAnimMove::visitActionSceneryObjectAnimMove(ActionSceneryObjectAnimMove* action)
{
	if (action->assetAnim_->name == oldAssetName_)
	{
		action->assetAnim_->unload();
		action->assetAnim_ = nullptr;
		action->assetAnim_ = AssetManager::getInstance().findAssetAnimMove(newAssetName_);
		if (action->assetAnim_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Move AssetAnim \"" << newAssetName_ << "\" could not be found. Asset replacement failed";
	}
}

void ActionVisitorCorrectAssetAnimRotate::visitActionSceneryObjectAnimRotate(ActionSceneryObjectAnimRotate* action)
{
	if (action->assetAnim_->name == oldAssetName_)
	{
		action->assetAnim_->unload();
		action->assetAnim_ = nullptr;
		action->assetAnim_ = AssetManager::getInstance().findAssetAnimRotate(newAssetName_);
		if (action->assetAnim_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Rotate AssetAnim \"" << newAssetName_ << "\" could not be found. Asset replacement failed";
	}
}

ActionVisitorCorrectAssetAnimScale::ActionVisitorCorrectAssetAnimScale(const QString& oldAssetName, const QString& newAssetName) 
	: ActionVisitorCorrectAssetBase(oldAssetName, newAssetName)
{
}

void ActionVisitorCorrectAssetAnimScale::visitActionSceneryObjectAnimScale(ActionSceneryObjectAnimScale* action)
{
	if (action->assetAnim_->name == oldAssetName_)
	{
		action->assetAnim_->unload();
		action->assetAnim_ = nullptr;
		action->assetAnim_ = AssetManager::getInstance().findAssetAnimScale(newAssetName_);
		if (action->assetAnim_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Scale AssetAnim \"" << newAssetName_ << "\" could not be found. Asset replacement failed";
	}
}

void ActionVisitorCorrectMusicPlaylist::visitActionAudioSetMusic(ActionAudioSetMusic* action)
{
	for (QString& path : action->musicPlaylist_.songFilesPaths_)
		if (path == oldAssetName_)
			path = newAssetName_;
}

void ActionVisitorCorrectSounds::visitActionAudioSetSounds(ActionAudioSetSounds* action) 
{
	for (Sound& sound : action->sounds_)
		if (sound.soundFile_ == oldAssetName_)
			sound.soundFile_ = newAssetName_;
}

void ActionVisitorCorrectBackgroundAssetImage::visitActionSetBackground(ActionSetBackground* action) 
{
	if (action->assetImage_->name == oldAssetName_)
	{
		action->assetImage_->unload();
		action->assetImage_ = nullptr;
		action->assetImage_ = AssetManager::getInstance().findAssetImageSceneryBackground(newAssetName_);
		if (action->assetImage_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetImageMissing << "SceneryObject AssetImage \"" << newAssetName_ << "\" could not be found. Definition file might be corrupted";
	}
}

void ActionVisitorCorrectSceneryObjectAssetImage::visitActionSceneryObjectSetImage(ActionSceneryObjectSetImage* action)
{
	if (action->assetImage_->name == oldAssetName_)
	{
		action->assetImage_->unload();
		action->assetImage_ = nullptr;
		action->assetImage_ = AssetManager::getInstance().findAssetImageSceneryObject(newAssetName_);
		if (action->assetImage_ == nullptr)
			qCritical() << NovelLib::ErrorType::AssetImageMissing << "Background AssetImage \"" << newAssetName_ << "\" could not be found. Definition file might be corrupted";
	}
}