#include "Novel/Action/Audio/ActionAudioSetMusic.h"
#include "Novel/Action/Audio/ActionAudioSetSounds.h"
#include "Novel/Data/Save/NovelState.h"
#include "Novel/Data/Scene.h"

void ActionAudioSetMusic::run()
{
	qInfo() << "Music was changed in Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	ActionAudio::run();

	MusicPlaylist* sceneryMusicPlaylist = &(NovelState::getCurrentlyLoadedState()->scenery.musicPlaylist);
	*sceneryMusicPlaylist = musicPlaylist_;

	if (onRun_) 
		onRun_(sceneryMusicPlaylist);
}

void ActionAudioSetSounds::run()
{
	ActionAudio::run();

	QList<SoundEffect>* scenerySounds = &(NovelState::getCurrentlyLoadedState()->scenery.sounds);
	*scenerySounds = sounds;

	if (onRun_) 
		onRun_(scenerySounds);
}
