#include "Novel/Action/Stat/ActionStatSetValue.h"

#include "Novel/Data/Scene.h"

ActionStatSetValue::ActionStatSetValue(Event* const parentEvent, Scene* const parentScene)
	: ActionStat(parentEvent, parentScene)
{
}

ActionStatSetValue::ActionStatSetValue(Event* const parentEvent, Scene* const parentScene, const QString& statName_, const QString& expression)
	: ActionStat(parentEvent, parentScene, statName_), expression(expression)
{
	checkForErrors(true);
}

ActionStatSetValue& ActionStatSetValue::operator=(const ActionStatSetValue& obj)
{
	if (this == &obj) return *this;

	ActionStat::operator=(obj);
	onRun_     = obj.onRun_;
	expression = obj.expression;

	return *this;
}

bool ActionStatSetValue::operator==(const ActionStatSetValue& obj) const
{
	if (this == &obj) return true;

	return	ActionStat::operator==(obj) &&
			expression == obj.expression;
}

bool ActionStatSetValue::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionStat::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionStatSetValue of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//TODO: check `expression` by trying to parse it with an evaluator
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an ActionStatSetValue of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}
	return false;
}

void ActionStatSetValue::serializableLoad(QDataStream& dataStream)
{
	ActionStat::serializableLoad(dataStream);
	dataStream >> expression;
	checkForErrors();
}

void ActionStatSetValue::serializableSave(QDataStream& dataStream) const
{
	ActionStat::serializableSave(dataStream);
	dataStream << expression;
}