#include "Novel/Action/Visual/ActionSceneryObject.h"
#include "Novel/Data/Scene.h"

ActionSceneryObject::ActionSceneryObject(Event* const parentEvent, Scene* const parentScene)
	: Action(parentEvent, parentScene)
{
}

ActionSceneryObject::ActionSceneryObject(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName)
	: Action(parentEvent, parentScene), sceneryObjectName_(sceneryObjectName)
{
}

ActionSceneryObject& ActionSceneryObject::operator=(const ActionSceneryObject& obj)
{
	if (this == &obj) return *this;

	Action::operator=(obj);
	sceneryObjectName_ = obj.sceneryObjectName_;
	sceneryObject_     = obj.sceneryObject_;

	return *this;
}

bool ActionSceneryObject::operator==(const ActionSceneryObject& obj) const
{
	if (this == &obj) return true;

	return	Action::operator==(obj)                      &&
			sceneryObjectName_ == obj.sceneryObjectName_ &&
			sceneryObject_     == obj.sceneryObject_;
}

bool ActionSceneryObject::checkForErrors(bool bComprehensive) const
{
	bool bError = Action::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObject of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (!parentScene_->scenery.displayedCharacters.contains(sceneryObjectName_))
		{
			qCritical() << NovelLib::ErrorType::SceneryObjectInvalid << "No valid SceneryObject assigned. Was it deleted and not replaced?";
			if (sceneryObjectName_ != "")
				qCritical() << NovelLib::ErrorType::SceneryObjectMissing << "SceneryObject \"" << sceneryObjectName_ << "\" could not be found. Definition file might be corrupted";
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an ActionSceneryObject of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	return false;
}

void ActionSceneryObject::serializableLoad(QDataStream& dataStream)
{
	Action::serializableLoad(dataStream);
	dataStream >> sceneryObjectName_;
}

void ActionSceneryObject::serializableSave(QDataStream& dataStream) const
{
	Action::serializableSave(dataStream);
	dataStream << sceneryObjectName_;
}
