#include "Novel/Action/Visual/ActionSetBackground.h"

#include "Novel/Data/Scene.h"

ActionSetBackground::ActionSetBackground(Event* const parentEvent, Scene* const parentScene)
	: Action(parentEvent, parentScene)
{
}

ActionSetBackground::ActionSetBackground(Event* const parentEvent, Scene* const parentScene, const QString& assetImageName, const  TransitionType transitionType, const double transitionTime)
	: Action(parentEvent, parentScene), assetImageName_(assetImageName), transitionType(transitionType), transitionTime(transitionTime)
{
	assetImage_ = AssetManager::getInstance().findAssetImageSceneryBackground(assetImageName_);

	//if (assetImage_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetImageMissing << "Background AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSetBackground& ActionSetBackground::operator=(const ActionSetBackground& obj)
{
	if (this == &obj) return *this;

	Action::operator=(obj);
	onRun_          = obj.onRun_;
	assetImageName_ = obj.assetImageName_;
	assetImage_     = obj.assetImage_;
	transitionType  = obj.transitionType;
	transitionTime  = obj.transitionTime;

	return *this;
}

bool ActionSetBackground::operator==(const ActionSetBackground& obj) const
{
	if (this == &obj) return true;

	return	Action::operator==(obj)                &&
			assetImageName_ == obj.assetImageName_ &&
			assetImage_     == obj.assetImage_     &&
			transitionType  == obj.transitionType  &&
			transitionTime  == obj.transitionTime;
}

bool ActionSetBackground::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSetBackground::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSetBackground of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (assetImage_ == nullptr)
		{
			qCritical() << NovelLib::ErrorType::AssetImageInvalid << "No valid Background AssetImage assigned. Was it deleted and not replaced?";
			if (assetImageName_ == "")
				qCritical() << NovelLib::ErrorType::AssetImageMissing << "Background AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an ActionSetBackground of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	return false;
}

void ActionSetBackground::setAssetImage(const QString& assetImageName)
{
	AssetImage* newAssetImage = nullptr;
	newAssetImage = AssetManager::getInstance().findAssetImageSceneryBackground(assetImageName);
	if (newAssetImage == nullptr)
		qCritical() << NovelLib::ErrorType::AssetImageMissing << "Background AssetImage \"" << assetImageName << "\" could not be found";
	else
	{
		assetImageName_ = assetImageName;
		assetImage_     = newAssetImage;
		checkForErrors(true);
	}
}

void ActionSetBackground::serializableLoad(QDataStream& dataStream)
{
	Action::serializableLoad(dataStream);
	dataStream >> assetImageName_ >> transitionType >> transitionTime;

	assetImage_ = AssetManager::getInstance().findAssetImageSceneryBackground(assetImageName_);
	//if (assetImage_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetImageMissing << "Background AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors();
}

void ActionSetBackground::serializableSave(QDataStream& dataStream) const
{
	Action::serializableSave(dataStream);
	dataStream << assetImageName_ << transitionType << transitionTime;
}