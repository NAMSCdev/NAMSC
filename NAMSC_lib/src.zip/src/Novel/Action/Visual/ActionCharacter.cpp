#include "Novel/Action/Visual/ActionCharacter.h"

#include "Novel/Data/Save/NovelState.h"
#include "Novel/Data/Scene.h"

ActionCharacter::ActionCharacter(Event* const parentEvent, Scene* const parentScene)
	: Action(parentEvent, parentScene)
{
}

ActionCharacter::ActionCharacter(Event* const parentEvent, Scene* const parentScene, const QString& characterName)
	: Action(parentEvent, parentScene), characterName_(characterName)
{
}

ActionCharacter& ActionCharacter::operator=(const ActionCharacter& obj)
{
	if (this == &obj) return *this;

	Action::operator=(obj);
	characterName_ = obj.characterName_;
	character_     = obj.character_;

	return *this;
}

bool ActionCharacter::operator==(const ActionCharacter& obj) const
{
	if (this == &obj) return true;

	return	Action::operator==(obj)              &&
			characterName_ == obj.characterName_ &&
			character_     == obj.character_;
}

bool ActionCharacter::checkForErrors(bool bComprehensive) const
{
	bool bError = Action::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionCharacter of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (!parentScene_->scenery.displayedCharacters.contains(characterName_))
		{
			qCritical() << NovelLib::ErrorType::CharacterInvalid << "No valid Character assigned. Was it deleted and not replaced?";
			if (characterName_ != "")
				qCritical() << NovelLib::ErrorType::CharacterMissing << "Character \"" << characterName_ << "\" could not be found. Definition file might be corrupted";
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an ActionCharacter of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	return false;
}

void ActionCharacter::serializableLoad(QDataStream& dataStream)
{
	Action::serializableLoad(dataStream);
	dataStream >> characterName_;

	checkForErrors();
}

void ActionCharacter::serializableSave(QDataStream& dataStream) const
{
	Action::serializableSave(dataStream);
	dataStream << characterName_;
}