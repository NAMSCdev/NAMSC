#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnim.h"

#include "Novel/Data/Scene.h"

template <class AnimNode>
ActionSceneryObjectAnim<AnimNode>::ActionSceneryObjectAnim<AnimNode>(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObject(parentEvent, parentScene)
{
}

template <class AnimNode>
ActionSceneryObjectAnim<AnimNode>::ActionSceneryObjectAnim(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: ActionSceneryObject(parentEvent, parentScene, sceneryObjectName), assetAnimName_(assetAnimName), startDelay(startDelay), speed(speed), timesPlayed(timesPlayed), bStopAnimationAtEventEnd(bStopAnimationAtEventEnd)
{
	//checkForErrors(true);
}

template <class AnimNode> 
ActionSceneryObjectAnim<AnimNode>& ActionSceneryObjectAnim<AnimNode>::operator=(const ActionSceneryObjectAnim<AnimNode>&obj)
{
	if (this == &obj)
		return *this;

	ActionSceneryObject::operator=(obj);
	assetAnimName_           = obj.assetAnimName_;
	assetAnim_               = obj.assetAnim_;
	startDelay               = obj.startDelay;
	speed                    = obj.speed;
	timesPlayed              = obj.timesPlayed;
	bStopAnimationAtEventEnd = obj.bStopAnimationAtEventEnd;

	return *this;
}

template <class AnimNode> 
bool ActionSceneryObjectAnim<AnimNode>::operator==(const ActionSceneryObjectAnim<AnimNode>& obj) const
{
	if (this == &obj)
		return *this;

	return	ActionSceneryObject::operator==(obj)                    &&
			assetAnimName_ == obj.assetAnimName_                    &&
			assetAnim_     == obj.assetAnim_                        &&
			startDelay     == obj.startDelay                        &&
			speed          == obj.speed                             &&
			timesPlayed    == obj.timesPlayed                       &&
			bStopAnimationAtEventEnd == obj.bStopAnimationAtEventEnd;
}

template <class AnimNode>
bool ActionSceneryObjectAnim<AnimNode>::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObject::checkForErrors(bComprehensive);
	if (bError)
	{
		//qDebug() << "Error occurred in an ActionSceneryObjectAnim of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (assetAnim_ == nullptr)
		{
			qCritical() << NovelLib::ErrorType::AssetAnimInvalid << "No valid AnimAsset assigned. Was it deleted and not replaced?";
			if (assetAnimName_ != "")
				qCritical() << NovelLib::ErrorType::AssetAnimMissing << "AssetAnim \"" << assetAnimName_ << "\" could not be found or read. Definition file might be corrupted";
			return true;
		}

		if (assetAnim_->checkForErrors(bComprehensive))
			return true;
		
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		//qDebug() << "Error occurred in an ActionSceneryObjectAnim of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	return false;
}

template <class AnimNode>
void ActionSceneryObjectAnim<AnimNode>::ensureResourcesAreLodaded()
{
	if (assetAnim_.isLoaded())
		assetAnim_.load();
}

template<typename AnimNode>
void ActionSceneryObjectAnim<AnimNode>::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObject::serializableLoad(dataStream);
	dataStream >> assetAnimName_ >> startDelay >> speed >> timesPlayed >> bStopAnimationAtEventEnd;
	//assetAnim_ is loaded in a derived class
}

template<typename AnimNode>
void ActionSceneryObjectAnim<AnimNode>::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObject::serializableSave(dataStream);
	dataStream << assetAnimName_ << startDelay << speed << timesPlayed << bStopAnimationAtEventEnd;
}