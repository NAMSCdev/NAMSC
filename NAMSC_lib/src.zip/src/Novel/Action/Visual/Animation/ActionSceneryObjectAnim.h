#pragma once
#include "Novel/Action/Visual/ActionSceneryObject.h"

#include "Novel/Data/Asset/AssetAnim.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"

///Creates AnimatorSceneryObjectColor and adds it to the Scenery, which will perform some Animation on a SceneryObject
template<typename AnimNode>
class ActionSceneryObjectAnim : public ActionSceneryObject
{
public:
	ActionSceneryObjectAnim(Event* const parentEvent, Scene* const parentScene) noexcept;
	/// \exception Error Couldn't find the SceneryObject named `sceneryObjectName`
	ActionSceneryObjectAnim(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd);
	ActionSceneryObjectAnim(const ActionSceneryObjectAnim& obj) = delete;
	ActionSceneryObjectAnim<AnimNode>& operator=(const ActionSceneryObjectAnim<AnimNode>& obj) noexcept;
	bool operator==(const ActionSceneryObjectAnim<AnimNode>& obj) const noexcept;
	bool operator!=(const ActionSceneryObjectAnim<AnimNode>& obj) const noexcept { return !(*this == obj); }

	/// \exception Error Couldn't find the SceneryObject named `sceneryObject_` is invalid
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

	virtual void run() override = 0;
	void end() override { NovelState::getCurrentlyLoadedState()->removeAnimator(animator); }

	void ensureResourcesAreLodaded();

	//SetAssetAnim is defined in concrete ActionSceneryObjectAnims
	AssetAnim<AnimNode>*       getAssetAnim()               { return assetAnim_; }
	const AssetAnim<AnimNode>* getAssetAnim() const         { return assetAnim_; }
	QString getAssetAnimName() const                        { return assetAnimName_; }

	/// In milliseconds
	uint startDelay                 = 0;

	double speed                    = 1.0;

	/// `-1` means infinite times
	int timesPlayed                 = 1;

	bool bStopAnimationAtEventEnd   = false;

protected:
	QString	             assetAnimName_ = "";
	AssetAnim<AnimNode>* assetAnim_     = nullptr;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream) override;

	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;

private:
	/// Tracking pointer for created Animator, so we know what to remove in `void end()`
	AnimatorSceneryObjectInterface* animator = nullptr;
};