#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnimMove.h"

#include "Novel/Data/Scene.h"

ActionSceneryObjectAnimMove::ActionSceneryObjectAnimMove(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObjectAnim(parentEvent, parentScene)
{
}

ActionSceneryObjectAnimMove::ActionSceneryObjectAnimMove(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName_, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: ActionSceneryObjectAnim(parentEvent, parentScene, sceneryObjectName, assetAnimName_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimMove(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::AssetAnimMissing << "Move AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSceneryObjectAnimMove& ActionSceneryObjectAnimMove::operator=(const ActionSceneryObjectAnimMove& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObjectAnim::operator=(obj);
	onRun_ = obj.onRun_;

	return *this;
}

bool ActionSceneryObjectAnimMove::operator==(const ActionSceneryObjectAnimMove& obj) const
{
	if (this == &obj) return true;

	return ActionSceneryObjectAnim::operator==(obj);
}

bool ActionSceneryObjectAnimMove::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObjectAnim::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectAnimMove of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionSceneryObjectAnimMove of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionSceneryObjectAnimMove::setAssetAnim(const QString& assetAnimName)
{
	AssetAnimMove* newAssetAnim = nullptr;
	newAssetAnim = AssetManager::getInstance().findAssetAnimMove(assetAnimName);
	if (newAssetAnim == nullptr)
		qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Move AssetAnim \"" << assetAnimName << "\" could not be found";
	else
	{
		assetAnimName_ = assetAnimName;
		assetAnim_     = newAssetAnim;
		checkForErrors(true);
	}
}

void ActionSceneryObjectAnimMove::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObjectAnim::serializableLoad(dataStream);
	//if (assetAnimName_ == "")
	//	qCritical() << NovelLib::AssetAnimInvalid << "Move AssetAnim is not specified";

	assetAnim_ = AssetManager::getInstance().findAssetAnimMove(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::AssetAnimMissing << "Move AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";

	checkForErrors();
}

void ActionSceneryObjectAnimMove::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObjectAnim::serializableSave(dataStream);
}