#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnimFade.h"

#include "Novel/Data/Scene.h"

ActionSceneryObjectAnimFade::ActionSceneryObjectAnimFade(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObjectAnim(parentEvent, parentScene)
{
}

ActionSceneryObjectAnimFade::ActionSceneryObjectAnimFade(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const uint startDelay, const bool bStopAnimationAtEventEnd, const double duration, const bool bAppear, const bool bPerserveAnimation)
	: ActionSceneryObjectAnim(parentEvent, parentScene, sceneryObjectName, "", startDelay, 1.0, 1, bStopAnimationAtEventEnd), duration(duration), bAppear(bAppear), bPerserveAnimation(bPerserveAnimation)
{
	checkForErrors(true);
}

ActionSceneryObjectAnimFade& ActionSceneryObjectAnimFade::operator=(const ActionSceneryObjectAnimFade& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObjectAnim::operator=(obj);
	onRun_             = obj.onRun_;
	duration           = obj.duration;
	bAppear            = obj.bAppear;
	bPerserveAnimation = obj.bPerserveAnimation;

	return *this;
}

bool ActionSceneryObjectAnimFade::operator==(const ActionSceneryObjectAnimFade& obj) const
{
	if (this == &obj) return true;

	return	ActionSceneryObjectAnim::operator==(obj)    &&
			duration != obj.duration                    &&
			bAppear  != obj.bAppear                     &&
			bPerserveAnimation != obj.bPerserveAnimation;
}

bool ActionSceneryObjectAnimFade::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObjectAnim::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectAnimFade of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionSceneryObjectAnimFade of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionSceneryObjectAnimFade::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObjectAnim::serializableLoad(dataStream);
	dataStream >> duration >> bAppear >> bPerserveAnimation;
	checkForErrors();
}

void ActionSceneryObjectAnimFade::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObjectAnim::serializableSave(dataStream);
	dataStream << duration << bAppear << bPerserveAnimation;
}