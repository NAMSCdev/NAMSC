#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnimRotate.h"

#include "Novel/Data/Scene.h"

ActionSceneryObjectAnimRotate::ActionSceneryObjectAnimRotate(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObjectAnim<AnimNodeDouble1D>(parentEvent, parentScene)
{
}

ActionSceneryObjectAnimRotate::ActionSceneryObjectAnimRotate(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName_, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: ActionSceneryObjectAnim(parentEvent, parentScene, sceneryObjectName, assetAnimName_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimRotate(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::AssetAnimMissing << "Rotate AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSceneryObjectAnimRotate& ActionSceneryObjectAnimRotate::operator=(const ActionSceneryObjectAnimRotate& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObjectAnim::operator=(obj);
	onRun_ = obj.onRun_;

	return *this;
}

bool ActionSceneryObjectAnimRotate::operator==(const ActionSceneryObjectAnimRotate& obj) const
{
	if (this == &obj) return true;

	return ActionSceneryObjectAnim::operator==(obj);
}

bool ActionSceneryObjectAnimRotate::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObjectAnim::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectAnimRotate of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionSceneryObjectAnimRotate of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionSceneryObjectAnimRotate::setAssetAnim(const QString& assetAnimName)
{
	AssetAnimRotate* newAssetAnim = nullptr;
	newAssetAnim = AssetManager::getInstance().findAssetAnimRotate(assetAnimName);
	if (newAssetAnim == nullptr)
		qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Rotate AssetAnim \"" << assetAnimName << "\" could not be found";
	else
	{
		assetAnimName_ = assetAnimName;
		assetAnim_     = newAssetAnim;
		checkForErrors(true);
	}
}

void ActionSceneryObjectAnimRotate::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObjectAnim::serializableLoad(dataStream);

	assetAnim_ = AssetManager::getInstance().findAssetAnimRotate(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Rotate AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors();
}

void ActionSceneryObjectAnimRotate::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObjectAnim::serializableSave(dataStream);
}