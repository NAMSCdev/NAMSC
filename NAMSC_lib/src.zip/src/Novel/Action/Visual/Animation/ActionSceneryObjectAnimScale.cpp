#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnimScale.h"

#include "Novel/Data/Scene.h"

ActionSceneryObjectAnimScale::ActionSceneryObjectAnimScale(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObjectAnim(parentEvent, parentScene)
{
}

ActionSceneryObjectAnimScale::ActionSceneryObjectAnimScale(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName_, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: ActionSceneryObjectAnim(parentEvent, parentScene, sceneryObjectName, assetAnimName_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimScale(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::AssetAnimMissing << "Scale AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSceneryObjectAnimScale& ActionSceneryObjectAnimScale::operator=(const ActionSceneryObjectAnimScale& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObjectAnim::operator=(obj);
	onRun_ = obj.onRun_;

	return *this;
}

bool ActionSceneryObjectAnimScale::operator==(const ActionSceneryObjectAnimScale& obj) const
{
	if (this == &obj) return true;

	return ActionSceneryObjectAnim::operator==(obj);
}

bool ActionSceneryObjectAnimScale::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObjectAnim::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectAnimScale of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionSceneryObjectAnimScale of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionSceneryObjectAnimScale::setAssetAnim(const QString& assetAnimName)
{
	AssetAnimScale* newAssetAnim = nullptr;
	newAssetAnim = AssetManager::getInstance().findAssetAnimScale(assetAnimName);
	if (newAssetAnim == nullptr)
		qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Scale AssetAnim \"" << assetAnimName << "\" could not be found";
	else
	{
		assetAnimName_ = assetAnimName;
		assetAnim_     = newAssetAnim;
		checkForErrors(true);
	}
}

void ActionSceneryObjectAnimScale::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObjectAnim::serializableLoad(dataStream);

	assetAnim_ = AssetManager::getInstance().findAssetAnimScale(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Scale AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors();
}

void ActionSceneryObjectAnimScale::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObjectAnim::serializableSave(dataStream);
}