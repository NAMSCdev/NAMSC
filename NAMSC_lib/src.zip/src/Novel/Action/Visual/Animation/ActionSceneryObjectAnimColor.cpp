#include "Novel/Action/Visual/Animation/ActionSceneryObjectAnimColor.h"

#include "Novel/Data/Scene.h"

ActionSceneryObjectAnimColor::ActionSceneryObjectAnimColor(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObjectAnim(parentEvent, parentScene)
{
}

ActionSceneryObjectAnimColor::ActionSceneryObjectAnimColor(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: ActionSceneryObjectAnim(parentEvent, parentScene, sceneryObjectName, assetAnimName, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimColor(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Color AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSceneryObjectAnimColor& ActionSceneryObjectAnimColor::operator=(const ActionSceneryObjectAnimColor& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObjectAnim::operator=(obj);
	onRun_ = obj.onRun_;

	return *this;
}

bool ActionSceneryObjectAnimColor::operator==(const ActionSceneryObjectAnimColor& obj) const
{
	if (this == &obj) return true;

	return ActionSceneryObjectAnim::operator==(obj);
}

void ActionSceneryObjectAnimColor::setAssetAnim(const QString& assetAnimName)
{
	AssetAnimColor* newAssetAnim = nullptr;
	newAssetAnim = AssetManager::getInstance().findAssetAnimColor(assetAnimName);
	if (newAssetAnim == nullptr)
		qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Color AssetAnim \"" << assetAnimName << "\" could not be found";
	else
	{
		assetAnimName_ = assetAnimName;
		assetAnim_     = newAssetAnim;
		checkForErrors(true);
	}
}

bool ActionSceneryObjectAnimColor::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObjectAnim::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectAnimColor of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	//static auto errorChecker = [&](bool bComprehensive) -> bool
	//{
	//	return false;
	//};

	//if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	//{
	//	qDebug() << "Error occurred in an ActionSceneryObjectAnimColor of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
	//	return true;
	//}

	return false;
}

void ActionSceneryObjectAnimColor::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObjectAnim::serializableLoad(dataStream);

	assetAnim_ = AssetManager::getInstance().findAssetAnimColor(assetAnimName_);
	//if (assetAnim_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetAnimMissing << "Color AssetAnim \"" << assetAnimName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors();
}

void ActionSceneryObjectAnimColor::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObjectAnim::serializableSave(dataStream);
}