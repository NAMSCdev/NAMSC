#include "Novel/Action/Visual/ActionSceneryObjectSetImage.h"

#include "Novel/Data/Asset/AssetManager.h"
#include "Novel/Data/Scene.h"

ActionSceneryObjectSetImage::ActionSceneryObjectSetImage(Event* const parentEvent, Scene* const parentScene)
	: ActionSceneryObject(parentEvent, parentScene)
{
}

ActionSceneryObjectSetImage::ActionSceneryObjectSetImage(Event* const parentEvent, Scene* const parentScene, const QString& sceneryObjectName, const QString& assetImageName) 
	: ActionSceneryObject(parentEvent, parentScene, sceneryObjectName), assetImageName_(assetImageName)
{
	assetImage_ = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
	//if (assetImage_ == nullptr)
	//	qCritical() << NovelLib::ErrorType::AssetImageMissing << "SceneryObject AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors(true);
}

ActionSceneryObjectSetImage& ActionSceneryObjectSetImage::operator=(const ActionSceneryObjectSetImage& obj)
{
	if (this == &obj) return *this;

	ActionSceneryObject::operator=(obj);
	onRun_          = obj.onRun_;
	assetImageName_ = obj.assetImageName_;
	assetImage_     = obj.assetImage_;

	return *this;
}

bool ActionSceneryObjectSetImage::operator==(const ActionSceneryObjectSetImage& obj) const
{
	if (this == &obj) return true;

	return	ActionSceneryObject::operator==(obj)   &&
			assetImageName_ == obj.assetImageName_ &&
			assetImage_     == obj.assetImage_;
}

bool ActionSceneryObjectSetImage::checkForErrors(bool bComprehensive) const
{
	bool bError = ActionSceneryObject::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an ActionSceneryObjectSetImage of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (assetImage_ == nullptr)
		{
			qCritical() << NovelLib::ErrorType::AssetImageInvalid << "No valid SceneryObject AssetImage assigned. Was it deleted and not replaced?";
			if (assetImageName_ == "")
				qCritical() << NovelLib::ErrorType::AssetImageMissing << "SceneryObject AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
			return true;
		}
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an ActionSceneryObjectSetImage of Scene \"" << parentScene_->name << "\" Event " << parentEvent_->getIndex();
		return true;
	}

	return false;
}

void ActionSceneryObjectSetImage::setAssetImage(const QString& assetImageName)
{
	AssetImage* newAssetImage = nullptr;
	newAssetImage = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName);
	if (newAssetImage == nullptr)
		qCritical() << NovelLib::ErrorType::AssetImageMissing << "SceneryObject AssetImage \"" << assetImageName << "\" could not be found";
	else
	{
		assetImageName_ = assetImageName;
		assetImage_     = newAssetImage;
		checkForErrors(true);
	}
}

void ActionSceneryObjectSetImage::ensureResourcesAreLoaded()
{
	ActionSceneryObject::ensureResourcesAreLoaded();

	if (assetImage_->isLoaded())
		assetImage_->load();
}

void ActionSceneryObjectSetImage::serializableLoad(QDataStream& dataStream)
{
	ActionSceneryObject::serializableLoad(dataStream);
	dataStream >> assetImageName_;

	assetImage_ = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
//	if (assetImage_ == nullptr)
//		qCritical() << NovelLib::ErrorType::AssetImageMissing << "SceneryObject AssetImage \"" << assetImageName_ << "\" could not be found. Definition file might be corrupted";
	checkForErrors();
}

void ActionSceneryObjectSetImage::serializableSave(QDataStream& dataStream) const
{
	ActionSceneryObject::serializableSave(dataStream);
	dataStream << assetImageName_;
}