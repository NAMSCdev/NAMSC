#include "Novel/Action/ActionsAll.h"

#include "Novel/Data/Save/NovelState.h"

//ANIMS


void ActionCharacter::run()
{
	Action::run();
	character_ = NovelState::getCurrentlyLoadedState()->scenery.
}


void ActionCharacterSetVoice::run() 
{
	ActionCharacter::run();
	


	if (onRun_)
		onRun_(animator);
}

void ActionSceneryObjectAnimColor::run()
{
	ActionSceneryObjectAnim<AnimNodeDouble4D>::run();

	AnimatorSceneryObjectColor* animator = new AnimatorSceneryObjectColor(sceneryObjectName_, assetAnim_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd);
	//The ownership of the pointer is transferred here, so no memory leak occurrs
	NovelState::getCurrentlyLoadedState()->addAnimator(animator);

	if (onRun_)
		onRun_(animator);
}

void ActionSceneryObjectAnimMove::run()
{
	ActionSceneryObjectAnim<AnimNodeDouble2D>::run();

	AnimatorSceneryObjectMove* animator = new AnimatorSceneryObjectMove(sceneryObjectName_, assetAnim_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd);
	//The ownership of the pointer is transferred here, so no memory leak occurrs
	NovelState::getCurrentlyLoadedState()->addAnimator(animator);

	if (onRun_)
		onRun_(animator);
}

void ActionScenery	ObjectAnimRotate::run()
{
	ActionSceneryObjectAnim<AnimNodeDouble1D>::run();

	AnimatorSceneryObjectRotate* animator = new AnimatorSceneryObjectRotate(sceneryObjectName_, assetAnim_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd);
	//The ownership of the pointer is transferred here, so no memory leak occurrs
	NovelState::getCurrentlyLoadedState()->addAnimator(animator);

	if (onRun_)
		onRun_(animator);
}

void ActionSceneryObjectAnimScale::run()
{
	ActionSceneryObjectAnim<AnimNodeDouble2D>::run();

	AnimatorSceneryObjectScale* animator = new AnimatorSceneryObjectScale(sceneryObjectName_, assetAnim_, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd);
	//The ownership of the pointer is transferred here, so no memory leak occurrs
	NovelState::getCurrentlyLoadedState()->addAnimator(animator);

	if (onRun_)
		onRun_(animator);
}

void ActionSceneryObjectAnimFade::run()
{
	ActionSceneryObject::run();
	//AnimatorSceneryObjectVisibility* animator = new AnimatorSceneryObjectVisibility(sceneryObject_, assetAnim_, appearEffectType_, duration, );
	//The ownership of the pointer is transferred here, so no memory leak occurrs
	//NovelState::getCurrentlyLoadedState()->addAnimator(animator);

	//if (onRun_)
	//	onRun_(animator);
}
