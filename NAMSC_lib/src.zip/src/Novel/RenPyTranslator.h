#pragma once
#include "Global.h"

/// [very optional] Makes our engineer diploma project useful by giving it ability to translate itself into RenPy
/// [ultra optional] It should be possible to do the reverse as well
class RenpPyTranslator
{
	static void RenPyLoad();

	static void RenPySave();
};