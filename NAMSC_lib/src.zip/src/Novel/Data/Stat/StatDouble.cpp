#include "Novel/Data/Stat/StatDouble.h"

StatDouble::StatDouble(const QString& name, const QString& displayName, const bool bShow, const uint priority, 
							  const ShowNotification showNotification, const double value, const double min, const double max)
	: Stat(name, displayName, bShow, priority, showNotification), value(value), min(min), max(max)
{
}

StatDouble& StatDouble::operator=(const StatDouble& obj)
{
	if (this == &obj) return *this;

	Stat::operator=(obj);
	value = obj.value;
	min   = obj.min;
	max   = obj.max;

	return *this;
}

void StatDouble::serializableLoad(QDataStream& dataStream)
{
	Stat::serializableLoad(dataStream);
	dataStream >> value >> min >> max;
}

void StatDouble::serializableSave(QDataStream& dataStream) const
{
	Stat::serializableSave(dataStream);
	dataStream << value << min << max;
}