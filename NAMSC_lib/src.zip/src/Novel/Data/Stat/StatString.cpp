#pragma once
#include "Novel/Data/Stat/StatString.h"

StatString::StatString(const QString& name, const QString& displayName, const bool bShow, const uint priority,
					   const ShowNotification showNotification, const QString& value, const uint maxChars) 
	: Stat(name, displayName, bShow, priority, showNotification), value(value), maxChars(maxChars)
{ 
}

StatString& StatString::operator=(const StatString& obj)
{
	if (this == &obj) return *this;

	Stat::operator=(obj);
	value    = obj.value;
	maxChars = obj.maxChars;

	return *this;
}

void StatString::serializableLoad(QDataStream& dataStream)
{
	Stat::serializableLoad(dataStream);
	dataStream >> value >> maxChars;
}

void StatString::serializableSave(QDataStream& dataStream) const
{
	Stat::serializableSave(dataStream);
	dataStream << value << maxChars;
}