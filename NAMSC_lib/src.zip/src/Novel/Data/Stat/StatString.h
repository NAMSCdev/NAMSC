#pragma once
#include "Novel/Data/Stat/Stat.h"

/// A Stat with a string value
class StatString final : public Stat
{
public:
	StatString() noexcept = default;
	StatString(const QString& name, const QString& displayName, const bool bShow, const uint priority,
			   const ShowNotification showNotification, const QString& value, const uint maxChars);
	StatString(const StatString& obj) = delete;
	StatString& operator=(const StatString& obj) noexcept;

	/// Assigns value to the Stat from a QString value
	/// Makes Assigment from EventInput and Evaluators very easy
	/// \param str Contains the value that must be assigned
	void setValueFromString(const QString& str) override;

	QString value;

	/// [optional] Max characters displayed
	uint maxChars = 0;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::StatString; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};