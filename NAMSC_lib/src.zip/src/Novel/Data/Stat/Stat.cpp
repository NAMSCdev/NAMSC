#include "Novel/Data/Stat/Stat.h"

Stat::Stat(const QString& name, const QString& displayName, const bool bShow, const uint priority, const ShowNotification showNotification) noexcept 
	: name(name), displayName(displayName), bShow(bShow), priority(priority), showNotification(showNotification) 
{
	if (displayName.isEmpty())
		this->displayName = name;
}

Stat& Stat::operator=(const Stat& obj) 
{
	if (this == &obj) return *this;

	name              = obj.name;
	displayName       = obj.displayName;
	bShow             = obj.bShow;
	priority          = obj.priority;
	showNotification  = obj.showNotification;

	return *this;
}

bool Stat::operator<(const Stat &rhs) const
{
	if (priority == rhs.priority)
		return (name.compare(rhs.name, Qt::CaseInsensitive) < 0);
	return priority < rhs.priority;
}

void Stat::serializableLoad(QDataStream& dataStream)
{
	dataStream >> name >> displayName >> bShow >> priority >> showNotification;
}

void Stat::serializableSave(QDataStream& dataStream) const
{
	dataStream << getType() << name << displayName << bShow << priority << showNotification;
}