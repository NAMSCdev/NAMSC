#pragma once
#include "Novel/Data/Stat/Stat.h"

/// A Stat with a floating-point value
class StatDouble final : public Stat
{
public:
	StatDouble() noexcept = default;
	StatDouble(const QString& name, const QString& displayName, const bool bShow, const uint priority, 
			   const ShowNotification showNotification, const double value, const double min, const double max);
	StatDouble(const StatDouble& obj) noexcept { *this = obj; }
	StatDouble& operator=(const StatDouble& obj) noexcept;

	/// Assigns value to the Stat from a QString value
	/// Makes Assigment from EventInput and Evaluators very easy
	/// \param str Contains the value that must be converted and assigned
	void setValueFromString(const QString& str) override;

	/// Every Stat has `value` field, but not all must have `max` and/or `min`
	/// This one does
	double	value, 
			min,
			max;
		
	///[optional] Label for the opposite Stat, used for a nicer display
	//QString oppositeStatLabel;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::StatDouble; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};