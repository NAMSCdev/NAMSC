#include "Novel/Data/Stat/StatLongLong.h"

StatLongLong::StatLongLong(const QString& name, const QString& displayName, const bool bShow, const uint priority, const ShowNotification showNotification, const int value, const int min, const int max)
	: Stat(name, displayName, bShow, priority, showNotification), value(value), min(min), max(max)
{
}

inline StatLongLong& StatLongLong::operator=(const StatLongLong& obj) noexcept
{
	if (this == &obj) return *this;

	Stat::operator=(obj);
	value = obj.value;
	min   = obj.min;
	max   = obj.max;

	return *this;
}


void StatLongLong::serializableLoad(QDataStream& dataStream)
{
	Stat::serializableLoad(dataStream);
	dataStream >> value >> min >> max;
}

void StatLongLong::serializableSave(QDataStream& dataStream) const
{
	Stat::serializableSave(dataStream);
	dataStream << value << min << max;
}