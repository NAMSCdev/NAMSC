#pragma once
#include "Novel/Data/Stat/Stat.h"

/// A Stat with an integer value
class StatLongLong final : public Stat
{
public:
	StatLongLong() noexcept = default;
	StatLongLong(const QString& name, const QString& displayName, const bool bShow, const uint priority, 
				 const ShowNotification showNotification, const int value, const int min, const int max);
	StatLongLong(const StatLongLong& obj) = delete;
	StatLongLong& operator=(const StatLongLong& obj) noexcept;

	/// \exception Error Could not perform converstion to the desired Stat's type
	void setValueFromString(const QString& valueInText) override;

	long long value,
			  min,
			  max;

	///[optional] Label for the opposite Stat, used for a nicer display
	//QString oppositeStatLabel;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::StatLongLong; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};