#pragma once

#include <QImage>
#include <QDate>
#include <QJSEngine>

#include "Novel/Data/Visual/Scenery/Scenery.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"
#include "Novel/Data/Stat/Stat.h"

/// Contains data about the Novel progression and Stats
class NovelState final
{
    //Friends for serialization
    friend QDataStream& operator>>(QDataStream&, NovelState&);
    friend QDataStream& operator<<(QDataStream&, const NovelState&);
public:
    NovelState() noexcept = default;
    NovelState(NovelState& obj) = delete;
    NovelState& operator=(const NovelState& obj) noexcept;

    static NovelState* getCurrentlyLoadedState();

    void addAnimator(AnimatorSceneryObjectInterface* animator);

    /// \exception Error Couldn't find the Stat named `name`
    Stat* findStat(const QString& statName_) { return stats_.value(statName_); }

    QDate saveDate = QDate::currentDate();

    QImage screenshot;

    /// Current Media
    Scenery scenery;

    int saveSlot = -1;

    /// The Scene->Event that the NovelState is in, which marks the Player's progression 
    uint sceneID = 0,
         eventID = 0;

    QJSEngine engine;

private:
    /// Loads SceneryObject definitions (meaning they will be reset to the default values) from a single file
    /// \todo implement this
    void loadSceneryObjects()
    {

    }

    /// Loads Stats definitions (meaning they will be reset to the default values) from a single file
    /// \todo implement this
    void loadCharacters()
    {

    }

    /// Loads Stats definitions (meaning they will be reset to the default values) from a single file
    /// \todo implement this
    void loadStats()
    {

    }

    QHash<QString, QPointer<Stat>> stats_;

    //---SERIALIZATION---
    /// Loading an object from a binary file
    /// \param dataStream Stream (presumably connected to a QFile) to read from
    void serializableLoad(QDataStream& dataStream);
    /// Saving an object to a binary file
    /// \param dataStream Stream (presumably connected to a QFile) to save to
    void serializableSave(QDataStream& dataStream) const;
};




inline NovelState& NovelState::operator=(const NovelState& obj)
{
    if (this == &obj) return *this;

    saveDate = obj.saveDate;
    screenshot = obj.screenshot;
    scenery  = obj.scenery;
    saveSlot = obj.saveSlot;
    sceneID  = obj.sceneID;
    eventID  = obj.eventID;
    stats_   = obj.stats_;

    return *this;
}