#pragma once
//#include "Novel/Data/Novel.h"
#include "Novel/Data/Asset/AssetManager.h"

#include "Novel/Data/Audio/AudioSettings.h"
#include "Novel/Data/Audio/Sound.h"
#include "Novel/Data/Audio/SoundEffect.h"
#include "Novel/Data/Audio/MusicPlaylist.h"

#include "Novel/Data/Save/NovelState.h"

#include "Novel/Data/Stat/Stat.h"
#include "Novel/Data/Stat/StatDouble.h"
#include "Novel/Data/Stat/StatLongLong.h"
#include "Novel/Data/Stat/StatString.h"

#include "Novel/Data/Text/Sentence.h"
#include "Novel/Data/Text/Translation.h"
#include "Novel/Data/Text/Voice.h"

#include "Novel/Data/Visual/Animation/AnimNode.h"
#include "Novel/Data/Visual/Animation/AnimatorBase.h"
#include "Novel/Data/Visual/Animation/AnimatorInterface.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObject.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectColor.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectRotate.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectMove.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectScale.h"

#include "Novel/Data/Visual/Scenery/SceneryObject.h"
#include "Novel/Data/Visual/Scenery/Character.h"
#include "Novel/Data/Visual/Scenery/Scenery.h"
#include "Novel/Data/Scene.h"
#include "Novel/Data/Chapter.h"

#include "Novel/Event/EventsAll.h"

//-----AUDIO

void AudioSettings::serializableLoad(QDataStream& dataStream)
{
    dataStream >> volume_ >> stereo_ >> timesPlayed >> delayBetweenReplays_;
}

void AudioSettings::serializableSave(QDataStream& dataStream) const
{
    dataStream << volume_ << stereo_ << timesPlayed << delayBetweenReplays_;
}

void Sound::serializableLoad(QDataStream& dataStream)
{
    dataStream >> audioFile_ >> audioSettings_;
}

void Sound::serializableSave(QDataStream& dataStream) const
{
    dataStream << audioFile_ << audioSettings_;
}

void SoundEffect::serializableLoad(QDataStream& dataStream)
{
    Sound::serializableLoad(dataStream);
    dataStream >> bPersistToNewEvent_ >> startDelay;
}

void SoundEffect::serializableSave(QDataStream& dataStream) const
{
    Sound::serializableSave(dataStream);
    dataStream << bPersistToNewEvent_ << startDelay;
}

void MusicPlaylist::serializableLoad(QDataStream& dataStream)
{
    uint audioFilesSize;
    dataStream >> audioFilesSize;
    for (uint i = 0u; i != audioFilesSize; ++i)
    {
        QString name_;
        dataStream >> name_;
        audioFilesPaths_.push_back(name_);
    }
    dataStream >> bRandom_ >> bPlayAtleastOnce_ >> audioSettings_ >> currentlyPlayed_;
}

void MusicPlaylist::serializableSave(QDataStream& dataStream) const
{
    dataStream << audioFilesPaths_.size();
    for (const QString& name_ : audioFilesPaths_)
        dataStream << name_;

    dataStream << bRandom_ << bPlayAtleastOnce_ << audioSettings_ << currentlyPlayed_;
}

//------SAVE

void NovelState::serializableLoad(QDataStream& dataStream)
{
    dataStream >> date_ >> image_ >> scenery_;
   
    uint statsSize = 0;
    dataStream >> statsSize;
    for (uint i = 0; i != statsSize; ++i)
    {
        Stat* stat = nullptr;
        switch (stats_[i].getType())
        {
            case NovelLib::SerializationID::StatString:
                stat = new StatString();
                break;
            case NovelLib::SerializationID::StatLongLong:
                stat = new StatLongLong();
                break;
            case NovelLib::SerializationID::StatDouble:
                stat = new StatDouble();
                break;
            default:
                qCritical() << "Could not find a Stat's type: " << static_cast<int>(stats_[i].getType()) << '!';
                break;
        }
        dataStream >> *stat;
        stats_.emplace_back(stat);
    }
    dataStream >> saveSlot_ >> sceneID_ >> eventID_;
}

void NovelState::serializableSave(QDataStream& dataStream) const
{
    dataStream << date_ << image_ << scenery_ << stats_.size();
    for (const Stat &stat : stats_)
        dataStream << stat;

    dataStream << saveSlot_ << sceneID_ << eventID_;
}

//-----TEXT
//This constructor is a special guest here, because it needs to grab a Voice from Novel, which is impossible in header file due to looping
void Translation::serializableLoad(QDataStream& dataStream)
{
    uint translationsSize;
    dataStream >> translationsSize;

    for (uint i = 0; i != translationsSize; ++i)
    {
        QPair<QString, AssetText> pair;
        dataStream >> pair;
        translations_.insert(pair.first, pair.second);
    }
}

void Translation::serializableSave(QDataStream& dataStream) const
{
    dataStream << NovelLib::SerializationID::Translation << translations_.size();
    for (auto it = translations_.constKeyValueBegin(); it != translations_.constKeyValueEnd(); ++it)
        dataStream << *it;
}



void Voice::serializableLoad(QDataStream& dataStream)
{
    dataStream >> fontName_ >> fontSize_ >> bold_ >> italic_ >> underscore_ >> color_ >> alignment_ >> lipSync_;
}

void Voice::serializableSave(QDataStream& dataStream) const
{
    dataStream << NovelLib::SerializationID::Voice << fontName_ << fontSize_ << bold_ << italic_ << underscore_ << color_ << alignment_ << lipSync_;
}

//-----ANIM

void AnimNodeBase::serializableLoad(QDataStream& dataStream)
{
    dataStream >> startDelay >> interpolationMethod_;
}

void AnimNodeBase::serializableSave(QDataStream& dataStream) const
{
    dataStream << startDelay << interpolationMethod_;
}

template<uint dimension>
void AnimNodeDouble<dimension>::serializableLoad(QDataStream& dataStream)
{
    AnimNodeBase::serializableLoad(dataStream);
    for (uint i = 0; i != dimension; ++i)
        dataStream >> state_[dimension];
}

template<uint dimension>
void AnimNodeDouble<dimension>::serializableSave(QDataStream& dataStream) const
{
    AnimNodeBase::serializableSave(dataStream);
    for (uint i = 0; i != dimension; ++i)
        dataStream << state_[dimension];
}

template<uint dimension>
void AnimNodeLongLong<dimension>::serializableLoad(QDataStream& dataStream)
{
    AnimNodeBase::serializableLoad(dataStream);
    for (uint i = 0; i != dimension; ++i)
        dataStream >> state_[dimension];
}

template<uint dimension>
void AnimNodeLongLong<dimension>::serializableSave(QDataStream& dataStream) const
{
    AnimNodeBase::serializableSave(dataStream);
    for (uint i = 0; i != dimension; ++i)
        dataStream << state_[dimension];
}

void AnimatorInterface::serializableLoad(QDataStream& dataStream)
{
    dataStream >> startDelay >> speed >> timesPlayed >> assetAnimName_;
}

void AnimatorInterface::serializableSave(QDataStream& dataStream) const
{
    dataStream << startDelay << speed << timesPlayed << assetAnimName_;
}

void AnimatorSceneryObjectInterface::serializableSave(QDataStream& dataStream) const
{
    AnimatorInterface::serializableSave(dataStream);
    dataStream << sceneryObjectName_;
}

void AnimatorSceneryObjectMove::serializableLoad(QDataStream& dataStream)
{
    AnimatorSceneryObject<AnimNodeDouble2D>::serializableLoad(dataStream);
    
    assetAnim_ = AssetManager::getInstance().findAssetAnimMove(assetAnimName_);
}

void AnimatorSceneryObjectColor::serializableLoad(QDataStream& dataStream)
{
    AnimatorSceneryObject<AnimNodeDouble4D>::serializableLoad(dataStream);

    assetAnim_ = AssetManager::getInstance().findAssetAnimColor(assetAnimName_);
}

void AnimatorSceneryObjectRotate::serializableLoad(QDataStream& dataStream)
{
    AnimatorSceneryObject<AnimNodeDouble1D>::serializableLoad(dataStream);
    
    assetAnim_ = AssetManager::getInstance().findAssetAnimRotate(assetAnimName_);
}

void AnimatorSceneryObjectScale::serializableLoad(QDataStream& dataStream)
{
    AnimatorSceneryObject<AnimNodeDouble2D>::serializableLoad(dataStream);

    assetAnim_ = AssetManager::getInstance().findAssetAnimScale(assetAnimName_);
}

//-----STATS



void StatString::serializableLoad(QDataStream& dataStream)
{
    Stat::serializableLoad(dataStream);
    dataStream >> value_ >> maxChars_;
}

void StatString::serializableSave(QDataStream& dataStream) const
{
    Stat::serializableSave(dataStream);
    dataStream << value_ << maxChars_;
}

void StatLongLong::serializableLoad(QDataStream& dataStream)
{
    Stat::serializableLoad(dataStream);
    dataStream >> value_ >> min_ >> max_;
}

void StatLongLong::serializableSave(QDataStream& dataStream) const
{
    Stat::serializableSave(dataStream);
    dataStream << value_ << min_ << max_;
}



//-----VISUAL
void SceneryObject::serializableLoad(QDataStream& dataStream)
{
    dataStream >> pos_ >> scale_ >> rotation_ >> color_[0] >> color_[1] >> color_[2] >> color_[3] >> label_ >> assetImageName_;
    
    assetImage_ = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
}
    
void SceneryObject::serializableSave(QDataStream& dataStream) const
{
    dataStream << pos_ << scale_ << rotation_ << color_[0] << color_[1] << color_[2] << color_[3] << label_ << assetImageName_;
}

void Character::serializableSave(QDataStream& dataStream) const
{
    SceneryObject::serializableSave(dataStream);
    dataStream << defaultVoiceName_;
}

void Chapter::serializableSave(QDataStream& dataStream) const
{
    dataStream << name;
    if (parent_)
        dataStream << parent_->name;
    else
        dataStream << QString("");
}

void Scenery::serializableLoad(QDataStream& dataStream)
{
        
}

void Scenery::serializableSave(QDataStream& dataStream) const
{

}

void NovelSettings::serializableLoad(QDataStream& dataStream)
{
    dataStream >> bStatsVisible_ >> bStatsNotification_ >> language_ >> defaultLanguage_
               >> lastSave_ >> cps_ >> nextButton_ >> mouseClick_ >> version_ >> resolution_;
}

void NovelSettings::serializableSave(QDataStream& dataStream) const
{
    dataStream << bStatsVisible_ << bStatsNotification_ << language_ << defaultLanguage_
               << lastSave_ << cps_ << nextButton_ << mouseClick_ << version_ << resolution_;
}

void Scene::serializableLoad(QDataStream& dataStream)
{
    dataStream >> label_;
    uint size;
    dataStream >> size;
    for (uint i = 0; i != size; ++i)
    {
        Event* ev;
        NovelLib::SerializationID type;
        dataStream >> type;
        switch (type)
        {
        case NovelLib::SerializationID::EventChoice:
            ev = new EventChoice();
            break;
        case NovelLib::SerializationID::EventEndIf:
            ev = new EventEndIf();
            break;
        case NovelLib::SerializationID::EventIf:
            ev = new EventIf();
            break;
        case NovelLib::SerializationID::EventInput:
            ev = new EventInput();
            break;
        case NovelLib::SerializationID::EventJump:
            ev = new EventJump();
            break;
        case NovelLib::SerializationID::EventNarrate:
            ev = new EventNarrate();
            break;
        case NovelLib::SerializationID::EventDialogue:
            ev = new EventDialogue();
            break;
        case NovelLib::SerializationID::EventWait:
            ev = new EventWait();
            break;
        default:
            qCritical() << "Could not find a Stat's type: " << static_cast<int>(type) << '!';
            break;
        }
        dataStream >> *ev;
        events_.emplace_back(ev);
        dataStream >> scenery_;
    }
}

void Scene::serializableSave(QDataStream& dataStream) const
{
    dataStream << label_ << events_.size();
    for (const Event& ev : events_)
        dataStream << ev;
    dataStream << scenery_;
}