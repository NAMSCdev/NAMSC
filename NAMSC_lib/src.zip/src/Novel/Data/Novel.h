#pragma once

#include <Novel/Data/NovelSettings.h>
#include <Novel/Data/Visual/Scenery/Character.h>
#include <Novel/Data/Visual/Scenery/Scenery.h>
#include <Novel/Data/Save/NovelState.h>
#include <Novel/Data/Text/Voice.h>

/// The entire Visual Novel
/// **Singleton**
class Novel final : public NovelFlowInterface
{
	friend NovelState;
public:
	static Novel& getInstance()
	{
		static Novel instance;
		return instance;
	}

	Novel() {}
	Novel(const Novel&) = delete;
	Novel& operator=(const Novel&) = delete;

	void addChapter(QPair<QString, int>& chapter)	{ chapters_.push_back(chapter); }
	void removeChapter(QPair<QString, int> chapter) { chapters_.push_back(chapter); }

	bool checkForErrors(bool bComprehensive = false) const override;

	/// Loads the entire Novel from multiple files
	void loadNovel(uint slot, bool createNew)
	{
		NovelSettings::load();
		if (createNew || !loadState(slot))
			newState(slot);
		loadAssetsDefs();
		loadVoices(); loadSceneryObjectsDefs(); loadCharacters();
		loadChapterDefs();
	}

	/// Creates a new NovelState (resets the old one, if exists) and loads it into the SaveSlot
	void newState(uint slot);
	/// Loads player's NovelState from a SaveFile in the given SaveSlot
	bool loadState(uint slot);
	/// Saves player's NovelState to a SaveFile in the given SaveSlot
	void saveState(uint slot);

	void run() override;
	void update() override;
	void end() override;

	void syncWithSave() override;
	
	/// \exception Error The Voice named `voiceName_` could not be found in `voices_` container
	Voice* findVoice(const QString& voiceName_) { return NovelLib::findInArray(voiceName_, voices_); }
	
	/// \exception The Character named `characterName` could not be found in `characters_` container
	Character* findCharacter(const QString& characterName) { return NovelLib::findInArray(characterName, characters_); }

	/// \exception The Character named `sceneryObjectName` could not be found in `characters_` container
	SceneryObject* findSceneryObject(const QString& sceneryObjectName); { return NovelLib::findInArray(sceneryObjectName, sceneryObjects_); }

	/// Returns Chapter's name from ID
	const QString	getChapter(const int id); 

	const NovelState* getCurrentStateAtSceneBegin() { return &saveSceneBegin_; }

	QString nextFreeSceneName();
	
	QString nextFreeChapterName();

	QHash<QString, Voice> voices;

	QHash<QString, SceneryObject> sceneryObjectDefaults_;

	QHash<QString, Character> characterDefaults_;

	QHash<QString, Chapter> chapters_;

	QHash<QString, Scene> scenes_;

private:
	inline void	loadAssetsDefinitions();

	/// Loads Voices from a single file
	inline void	loadVoices();

	/// Loads SceneryObject definitions (not its resources) from a single file
	inline void	loadSceneryObjectsDefs();

	/// Loads Character definitions (not its resources) from a single file
	inline void	loadCharacters();

	/// Loads Chapters definitions (not its resources) from a single file
	inline void	loadChapterDefs();

	/// Loads Chapter resources
	inline void	loadChapterResources(QString chapterName);

	/// Plays Music in the background
	QMediaPlayer musicPlayer_;

	/// This one refers to the begninning of the current Scene, as the game will always be saved at this point if the User chooses to save
	/// It is needed to replay the last Scene, so the User does not lose the context of the Novel upon loading, as this contains Media changes that will not be journalized anywhere else
	NovelState saveSceneBegin_;

	/// Contains current the player's progression, including changes made past the beginning of the Scene
	NovelState state_;
};