#include "Novel/Data/Asset/AssetImage.h"

AssetImage::AssetImage(const QString& name, const uint size, const uint pos, const QString& path) noexcept
	: Asset(name, size, pos, path)
{
}

bool AssetImage::checkForErrors(bool bComprehensive = false) const
{
	bool bError = Asset::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an AssetImage \"" << name << '\"';
		return true;
	}
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (bComprehensive)
		{
			if (!isLoaded())
			{
				AssetImage fake(name, size, pos, path);
				fake.load();
				fake.unload();
			}
		}

		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an AssetImage \"" << name << '\"';
		return true;
	}

	return false;
}

void AssetImage::load()
{
	//checkFileExistence();
	//if (size == 0)
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}
	//TODO: add some way to edit Images (even using external editors) in the Editor, then allow for compression to happen
	//img_ = new QImage(path_);
	//img = QPointer<QImage>();
	//QFile file(path);
	//if (!file.open(QIODevice::ReadOnly))
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}
	//QDataStream dataStream(&file);
	//dataStream.skipRawData(pos);

	//QPointer<char> data = QPointer<char>(new char[size]);
	//dataStream.readRawData(data.get(), size);

	//img = QPointer<QImage>(new QImage);
	//if (!img.get()->loadFromData(reinterpret_cast<uchar*>(data.get()), size))
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}

}

void AssetImage::save()
{
}

