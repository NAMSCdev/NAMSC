#include "Novel/Data/Asset/AssetAnim.h"

#include "Helpers.h"

AssetAnimBase::AssetAnimBase(const QString& name, const uint size, const uint pos, const QString& path)
	: Asset(name, size, pos, path)
{
}

template<typename AnimNode>
AssetAnim<AnimNode>::AssetAnim(const QString& name, const uint size, const uint pos, const QString& path)
	: AssetAnimBase(name, size, pos, path)
{
}

template<typename AnimNode>
bool AssetAnim<AnimNode>::checkForErrors(bool bComprehensive) const
{
	bool bError = Asset::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an AssetAnim \"" << name << '\"';
		return true;
	}

	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		//todo: check timeStamps
		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{	
		qDebug() << "Error occurred in an AssetAnim \"" << name << '\"';
		return true;
	}

	return false;
}

template<typename AnimNode>
void AssetAnim<AnimNode>::insertAnimNode(const AnimNode& newNode)
{
	if (animNodes_.contains(newNode.timeStamp))
	{
		qCritical() << "There already exists an AnimNode in the AssetAnim \"" << name << "\" with timestamp " << QString::number(newNode.timeStamp);
		return;
	}
	animNodes_.push_back(newNode);
	std::sort(animNodes_.begin(), animNodes_.end());
	bChanged_ = true;
}

template<typename AnimNode>
void AssetAnim<AnimNode>::load()
{
	//if (size_ == 0)
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}
	//checkFileExistence();
	//animNodes_.reset(new QList<AnimNode>);

	//QFile file(path_);
	//if (!file.open(QIODevice::ReadOnly))
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}
	//QDataStream dataStream(&file);
	//dataStream.skipRawData(pos_);

	//uint animNodesSize;
	//dataStream >> animNodesSize;

	//for (uint i = 0; i != animNodesSize; ++i)
	//{
	//	AnimNode node;
	//	dataStream >> node;

	//	animNodes_.get()->push_back(node));
	//}
}

template<typename AnimNode>
void AssetAnim<AnimNode>::save()
{
	//if (!bChanged_)
	//	return;

	//checkFileExistence();
	//QFile file(path_);
	//if (!file.open(QIODevice::ReadWrite))
	//{
	//	/// TODO: throw some Exception
	//	return;
	//}
	//QDataStream dataStream(&file);
	//QByteArray allData = file.readAll();
	//allData.remove(pos_, size_);

	//QByteArray newData;
	//QDataStream newDataStream(newData);
	//newDataStream << animNodes_->size();

	//for (const AnimNode& node : animNodes_)
	//	newDataStream << node;

	//allData.insert(pos_, newData);

	//uint oldSize = size_;
	//size_ = newData.size();

	//file.seek(0);
	//file.resize(0);
	//dataStream.writeRawData(allData, allData.size());

	//bChanged_ = false;

	//if (onSave)
	//	onSave(name_, oldSize, size_, pos_, path_);
}