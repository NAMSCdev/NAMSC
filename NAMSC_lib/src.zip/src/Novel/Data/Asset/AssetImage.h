#pragma once
#include "Novel/Data/Asset/Asset.h"

#include <QImage>
#include <QPointer>

/// Allows Image loading and its memory management
class AssetImage final : public Asset
{
public:
	AssetImage() noexcept = default;
	/// \exception Error Could not find/open/read the Resource file or the `assetImage_` couldn't be read as Image file (bad format)
	AssetImage(const QString& name, const uint size, const uint pos = 0, const QString& path = "");
	AssetImage(const AssetImage& obj)            = delete;
	AssetImage& operator=(const AssetImage& obj) = delete;

	/// \exception Error Could not find/open/read the Resource file / invalid `assetImage_`
	/// \todo implement this
	void load() override;
	bool isLoaded() const override  { return img_.get() != nullptr; }
	void unload() noexcept override { img_.clear(); }

	/// \exception Error Could not find/open/read the Resource file / invalid `assetImage_`
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

	/// Saves content changes (the Resource, not the definition)
	/// \exception Error Could not find/open/write to the file
	/// \todo implement this
	void save() override;

	const QImage* getImage() const  { return img_.get(); }

protected:
	QPointer<QImage> img_;
};