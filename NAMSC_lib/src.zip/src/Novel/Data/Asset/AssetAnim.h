#pragma once
#include "Novel/Data/Asset/Asset.h"

#include <QList>
#include <QString>

#include "Novel/Data/Visual/Animation/AnimNode.h"

/// Accepts AssetVisitor for AssetAnim class
class AssetAnimBase : public Asset
{
public:
	AssetAnimBase(const QString& name, const uint size, const uint pos = 0, const QString& path = "") noexcept;
};

/// Allows Animation loading and its memory management
template<typename AnimNode>
class AssetAnim final : public AssetAnimBase
{
public:
	AssetAnim() noexcept = default;
	/// \exception Error Could not find/open/read the Resource file or one of the AnimNode in `animNodes_` has a duplicate `timeStamp'
	AssetAnim(const QString& name, const uint size, const uint pos = 0, const QString& path = "");
	AssetAnim(const AssetAnim&)            = delete;
	AssetAnim& operator=(const AssetAnim&) = delete;

	/// \exception Error Could not find/open/read the Resource file / AnimNode in `animNodes_` has invalid `timeStamp`
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

	/// \exception Error Could not find/open/read the Resource file
	/// \todo implement this
	void load() override;
	bool isLoaded() const override              { return !animNodes_.isEmpty(); }
	void unload() noexcept override             { animNodes_.clear(); }

	/// Saves content changes (the Resource, not the definition)
	/// \exception Error Could not find/open/write to the file
	/// \todo implement this
	void save() override;

	const QList<AnimNode>* getAnimNodes() const { return &animNodes_; }

	/// \exception Error A node with the same `timeStamp` already exists in the `animNodes_` container
	/// \todo More intelligent inserting, so the sort is not needed
	void insertAnimNode(const AnimNode& newNode);

private:
	QList<AnimNode> animNodes_;
};

using AssetAnimColor  = AssetAnim<AnimNodeDouble4D>;
using AssetAnimMove   = AssetAnim<AnimNodeDouble2D>;
using AssetAnimRotate = AssetAnim<AnimNodeDouble1D>;
using AssetAnimScale  = AssetAnim<AnimNodeDouble2D>;