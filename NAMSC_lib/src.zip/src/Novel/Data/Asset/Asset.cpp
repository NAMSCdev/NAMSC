#include "Novel/Data/Asset/Asset.h"

#include <QFile>

Asset::Asset(const QString& name, const uint size, const uint pos, const QString& path)
	: name(name), size(size), path(path), pos(pos)
{
}

bool Asset::checkForErrors(bool bComprehensive) const
{
	bool bError = Asset::checkForErrors(bComprehensive);
	if (bError)
	{
		qDebug() << "Error occurred in an AssetImage \"" << name << '\"';
		return true;
	}
	static auto errorChecker = [&](bool bComprehensive) -> bool
	{
		if (!QFile::exists(path));
		{
			qCritical() << NovelLib::ErrorType::AssetAnimFileMissing << "Could not find Resource file \"" << path << '\"';
			return true;
		}

		return false;
	};

	if (NovelLib::catchExceptions(errorChecker, bComprehensive))
	{
		qDebug() << "Error occurred in an AssetImage \"" << name << '\"';
		return true;
	}

	return false;
}

void Asset::serializableLoad(QDataStream& dataStream)
{
	dataStream >> name >> size >> path >> pos;
}

void Asset::serializableSave(QDataStream& dataStream) const
{
	dataStream << name << size << path << pos;
}