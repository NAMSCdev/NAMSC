#pragma once

#include <QString>

#include "Exceptions.h"
#include "Helpers.h"
#include "Serialization.h"

/// Holds some Resources, which very likely take time to be loaded and allocate significant memory, so they should be loaded only when needed
class Asset
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Asset&);
	friend QDataStream& operator<<(QDataStream&, const Asset&);
public:
	Asset() noexcept = default;
	/// \exception Error Could not find/open/read the Resource file
	Asset(const QString& name, const uint size, const uint pos = 0, const QString& path = "");
	Asset(const Asset& obj)            = delete;
	Asset& operator=(const Asset& obj) = delete;
	// The destructor needs to be virtual, so the proper destructor will always be called when destroying an Asset pointer
	virtual ~Asset() = default;

	bool operator==(const QString& name) const { return this->name == name; }

	/// \exception Error Could not find/open/read the Resource file
	/// \todo more intelligent loading when it is a compact file, so it is not opened and closed multiple times (static members in AssetManager that open and close on demand should do the trick)
	virtual void load()           = 0;
	virtual bool isLoaded() const = 0;
	virtual void unload()         = 0;

	/// Saves content changes (the Resource, not the definition)
	/// \exception Error Could not find/open/write to the file
	/// \todo implement this
	virtual void save()           = 0;

	/// \exception Error Couldn't find/open/read the Resource file
	/// \return Whether an Error has occurred
	virtual bool checkForErrors(bool bComprehensive = false) const;

	/// Sets a function pointer that is called (if not nullptr) after the ActionAudioSetMusic's `void run()` allowing for data read
	//void setOnSaveListener(std::function<void(QString name, uint oldSize, uint size, uint pos, QString path)> onSave) { onSave_ = onSave; }

	QString	name = "";

	QString	path = "";

	/// [optional] If many Assets share the same binary file, it is needed to remember the position of every Asset
	uint pos     = 0;

	/// In bytes
	uint size    = 0;

protected:
	/// A function pointer that is called (if not nullptr) after the Asset's `void save() const` allowing for data read
	//std::function<void(QString name, uint oldSize, uint size, uint pos, QString path)> onSave_;

	/// Indicates if there were content changes (the Resource, not the definition)
	bool bChanged_ = false;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};