#pragma once

#include "Novel/Event/Event.h"
#include "Novel/Data/Visual/Scenery/Scenery.h"

// Forward declaration of a Novel, so we can save it as a parent
// Needed to check other Scenes in the Novel if they don't have the same label as we want to assign a new Scene
class Novel;

/// The logical unit of the Novel's flow in the [Novel](#Novel]
/// The Editor user should be able to create one whenever
class Scene : public NovelFlowInterface
{
	/// Our overlord
	friend class Novel;
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, SceneryObject&);
	friend QDataStream& operator<<(QDataStream&, const SceneryObject&);
public:
	Scene() {}
	Scene(const QString& label, QList<Event>&& events, Scenery&& scenery);

	/// Executes [Events](#Event) that are stored in the (`events` container](#events)
	/// \param offset The first [Event](#Event) to be executed from the container
	void run(uint offset) override;

	/// Removes an [Events](#Event) from the (`events` container](#events) and fixes all the others [Events](#Event)'s `executionOrders`(#Event#executionOrder) and corrects [Jumps](#Jump) or marks them as invalid
	/// \param executionOrder ID of an Event is equivalent with its order in execution. This one will be deleted
	void removeEvent(uint executionOrder);

	/// Inserts an [Events](#Event) into [`events` container](#events) at certain point
	/// Fixes all the others [Events's executionOrders](#Event#executionOrder) and corrects [Jumps](#Jump)
	/// \param executionOrder ID of an Event is equivalent with its order in execution. The even will be inserted past this `executionOrder`
	/// \param ev [Event](#Event) to be inserted
	void insertEvent(uint executionOrder, Event&& ev);

	/// Checks if the Scene's Events can load Definitions and Resources associated with them and don't have any other Errors, which would halt the Novel execution
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

	QString nextFreeSceneName();

	/// Automatically assigned upon creation or changed by the Editor User
	QString	name;
	Chapter* chapter;
	/// All the Events to be executed in the Scene
	QList<Event> events; 

	/// Currently displayed media of the Scene
	/// \todo [optional but high priority unless it is too much work] MAKE IT INCREMENTAL THROUGH ACTIONS INSTEAD
	Scenery	scenery;

private:

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);

	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline Scene::Scene(const QString& label, QList<Event>&& events, Scenery&& scenery) :
	label_(label), events_(events), scenery_(scenery)
{

}