#pragma once
//#include "Novel/Data/Novel.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectColor.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectMove.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectRotate.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectScale.h"

//AnimatorBase

template<typename AnimNode>
void AnimatorSceneryObject<AnimNode>::startAnimating()
{
    for (const AnimNode& node : animNodes_)
    {
        adjustedNodes_->emplaceBack(node);
        adjustedNodes_->back().startDelay = qRound(adjustedNodes_->back().startDelay * speed);
    }
    currentNode_ = adjustedNodes_->cbegin();
    nextNode_ = currentNode_ + 1;
    startTime_ = QTime::currentTime();
}

template<typename AnimNode>
AnimNode AnimatorBase<AnimNode>::currentAnimState()
{
    if (adjustedNodes_->size() == 0)
        return AnimNode();

    if (timesPlayed == 0)
        return adjustedNodes_->back();

    int elapsedTime = startTime_.msecsTo(QTime::currentTime());
    if (elapsedTime > adjustedNodes_->back().startDelay)
    {
        //Return the final state, if we are not asked to play the Animation again
        if (--timesPlayed == 0)
            return adjustedNodes_->back();

        //Reset the timer
        startTime_  += elapsedTime;
        currentNode_ = adjustedNodes_->cbegin();
        nextNode_    = currentNode_ + 1;
    }

    AnimNode ret = *currentNode;

    if (nextNode == adjustedNodes_->cend())
        return ret;

    double	deltaTime = elapsedTime - currentNode->startDelay,
        duration = nextNode->startDelay - currentNode->startDelay;
    switch (nextNode->interpolationMethod)
    {
    case AnimNode::AnimInterpolationMethod::Linear:
    default:
        for (uint i = 0; i != (sizeof(ret.state_) / sizeof(ret.state_[0])); ++i)
            ret.state_[i] += (nextNode->state_[i] - ret.state_[i]) * (deltaTime / duration);
        break;
    }
    return ret;
}

void AnimatorSceneryObjectColor::update()
{
    AnimNodeDouble4D node = currentAnimState();
#pragma unroll
    for (int i = 0; i != 4; ++i)
        sceneryObject_->color[i] = node.state_[i];
}

void AnimatorSceneryObjectMove::update()
{
    AnimNodeDouble2D node = currentAnimState();
    sceneryObject_->pos = QPoint(node.state_[0], node.state_[1]);
}

void AnimatorSceneryObjectRotate::update()
{
    AnimNodeDouble1D node = currentAnimState();
    sceneryObject_->rotation = node.state_[0];
}

void AnimatorSceneryObjectScale::update()
{
    AnimNodeDouble2D node = currentAnimState();
    sceneryObject_->scale = QSize(node.state_[0], node.state_[1]);
}
