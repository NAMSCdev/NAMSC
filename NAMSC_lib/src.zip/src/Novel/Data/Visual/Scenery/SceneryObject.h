#pragma once

#include <QGraphicsPixmapItem>

#include "Novel/Data/Asset/AssetManager.h"

/// Holds data for a drawable object
class SceneryObject
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, SceneryObject&);
	friend QDataStream& operator<<(QDataStream&, const SceneryObject&);
public:
	SceneryObject() noexcept = default;
	SceneryObject(const QString& name, const QString& assetImageName_, const QPoint pos, const QSize scale, const double rotationDegree, const QVarLengthArray<double, 4>& colorMultiplier, const bool bVisible);
	virtual ~SceneryObject() noexcept = default;

	/// \exception Error `assetImage_` is invalid
	virtual bool checkForErrors(bool bComprehensive = false) const;

	/// Updates the graphicsItem that reads drawing data from the SceneryObject
	/// \param graphicsItem The QGraphicsPixmapItem that will have its state updated
	void render(QGraphicsPixmapItem* graphicsItem) const
	{
		if (!assetImage_->isLoaded())
			assetImage_->load();

		if (graphicsItem->pixmap().isNull())
			graphicsItem->setPixmap(QPixmap::fromImage(*(assetImage_->getImage())));
	}

	///Changes assetImage of the SceneryObject and updates the QGraphicsPixmapItem associated with it if present
	void setImage(QString assetImageName_, QGraphicsPixmapItem* graphicsItem = nullptr)
	{
		setImage(assetImageName_);
		if (graphicsItem)
			graphicsItem->setPixmap(QPixmap::fromImage(*(assetImage_->getImage())));
	}

	/// \exception Error Couldn't load the `assetImage_`
	void ensureResourcesAreLoaded()
	{
		if (assetImage_ && !assetImage_->isLoaded())
			assetImage_->load();
	}

	QString name            = "";

	/// \todo [optional] allow for setting position in Z-dimension and do proper maths about it
	QPointF pos             = { 0.0, 0.0/*, 0.0*/ };

	QSizeF scale            = { 1.0, 1.0 };
	
	double rotationDegree   = 0.0;
	
	QVarLengthArray<double, 4> colorMultiplier = { 1.0, 1.0, 1.0, 1.0 };

	double alphaMultiplier  = 1.0;

	bool bVisible           = false;

protected:
	AssetImage* assetImage_ = nullptr;
	
	//[optional] create this class and it will store AssetImages with custom names for image filtering (useful in Editor)
	//QList<SceneryObjectPart> parts;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline SceneryObject::SceneryObject(const QString& name, const QString& assetImageName_, const QPoint pos, const QSize scale, const double rotationDegree, const QVarLengthArray<double, 4>& color, const bool bVisible)
	: name(name), pos(pos), scale(scale), rotationDegree(rotationDegree), colorMultiplier(colorMultiplier), bVisible(bVisible)
{
	assetImage_ = AssetManager::getInstance().findAssetImageSceneryObject(assetImageName_);
}