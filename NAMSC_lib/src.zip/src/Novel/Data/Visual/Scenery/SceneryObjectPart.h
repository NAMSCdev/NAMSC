#pragma once

/// This hasn't been thought through yet. It is very WIP. Sooo WIP it does not even exist for now
/// [update] It was decided to be optional and will not be implemented until we change our minds