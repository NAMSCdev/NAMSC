#pragma once

#include "Novel/Data/Audio/MusicPlaylist.h"
#include "Novel/Data/Audio/SoundEffect.h"
#include "Novel/Data/Asset/AssetManager.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"
#include "Novel/Data/Visual/Scenery/Character.h"

/// All the media managed by the library
struct Scenery
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Scenery&);
	friend QDataStream& operator<<(QDataStream&, const Scenery&);
public:
	Scenery() noexcept = default;
	Scenery(const Scenery& obj) = delete;
	Scenery& operator=(const Scenery& obj) noexcept;

	void startAnimating() const { for (const QPointer<AnimatorSceneryObjectInterface>& animator : animators) animator->run(); }

	void update() const { for (const QPointer<AnimatorSceneryObjectInterface>& animator : animators) animator->update(); }

	/// Ensures Assets amd Sounds are loaded and if not - loads them
	void ensureResourcesAreLoaded();

	/// All SceneryObjects' Animators, which - as the name suggets - play SceneryObjects' Animations
	QList<QPointer<AnimatorSceneryObjectInterface>> animators;

	QImage background;

	QHash<QString, Character> displayedCharacters;

	QHash<QString, SceneryObject> displayedSceneryObjects;

	/// Sounds that haven't been played yet, but they are supossed to be played at some point in time
	/// `void update()` should remove already played ones
	QList<SoundEffect> sounds;

	MusicPlaylist musicPlaylist;


private:
	void updateRender();

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline void Scenery::ensureResourcesAreLoaded()
{
	for (Character& character : displayedCharacters_)
		character.ensureResourcesAreLoaded();

	for (SceneryObject& sceneryObject : displayedSceneryObjects_)
		sceneryObject.ensureResourcesAreLoaded();

	for (Sound& sound : sounds)
		if (!sound.isLoaded())
			sound.load();
}

inline Scenery& Scenery::operator=(const Scenery& obj)
{
	if (this == &obj) return *this;

	displayedCharacters_     = obj.displayedCharacters_;
	displayedSceneryObjects_ = obj.displayedSceneryObjects_;
	animators			     = obj.animators;
	sounds                   = obj.sounds;
	musicPlaylist            = obj.musicPlaylist;
	background			     = obj.background;

	return *this;
}