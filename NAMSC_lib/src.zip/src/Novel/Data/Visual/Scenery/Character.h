#pragma once
#include "Novel/Data/Visual/Scenery/SceneryObject.h"

#include "Novel/Data/Asset/AssetImage.h"
#include "Novel/Data/Asset/AssetManager.h"

/// Represents a Character in the Novel
class Character final : public SceneryObject
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Character&);
	friend QDataStream& operator<<(QDataStream&, const Character&);
public:
	Character() noexcept = default;
	Character(const QString& defaultVoiceName);
	Character(const Character& obj) = delete;
	Character& operator=(const Character& obj) noexcept;

	/// Checks if the Character can load Definitions and Resources associated with it and doesn't have any other Errors, which would halt the Novel execution
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

private:
	/// Name of the default Voice that will be assigned to EventDialogue
	QString		defaultVoiceName_;
	/// Default Voice - formatting of the Text
	Voice*		defaultVoice_;

	//QString			idleLive2DAnimName;
	//AssetLive2DAnim *idleLive2DAnim;
	//QString			currentLive2DAnimName;
	//AssetLive2DAnim *currentLive2DAnim;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline Character& Character::operator=(const Character& obj) noexcept
{
	if (this == &obj) return *this;

	SceneryObject::operator=(obj);
	defaultVoiceName_ = obj.defaultVoiceName_;
	defaultVoice_     = obj.defaultVoice_;

	return *this;
}