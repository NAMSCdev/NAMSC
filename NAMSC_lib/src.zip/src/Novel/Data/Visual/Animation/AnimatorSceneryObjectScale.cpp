#pragma once	
#include "Novel/Data/Visual/Animation/AnimatorSceneryObject.h"

/// Does the maths behind Scale Animation
class AnimatorSceneryObjectScale final : public AnimatorSceneryObject<AnimNodeDouble2D>
{
public:
	AnimatorSceneryObjectScale() noexcept = default;
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed 
	AnimatorSceneryObjectScale(uint startDelay, double speed, int timesPlayed, const QString& assetAnimName, const QString& sceneryObjectName);
	AnimatorSceneryObjectScale(const AnimatorSceneryObjectScale& obj) noexcept { *this = obj; }
	AnimatorSceneryObjectScale& operator=(const AnimatorSceneryObjectScale& obj) noexcept;

	/// Changes colors of the SceneryObject
	void update() override;

	/// Checks if the AnimatorSceneryObjectScale can load Definitions and Resources associated with it and doesn't have any other Errors, which would halt the Novel execution
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

private:
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
};




inline AnimatorSceneryObjectScale::AnimatorSceneryObjectScale(uint startDelay, double speed, int timesPlayed, const QString& assetAnimName, const QString& sceneryObjectName) :
	AnimatorSceneryObject<AnimNodeDouble2D>(startDelay, speed, timesPlayed, sceneryObjectName)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimScale(assetAnimName_);
}

inline AnimatorSceneryObjectScale& AnimatorSceneryObjectScale::operator=(const AnimatorSceneryObjectScale& obj) noexcept
{
	if (this == &obj) return *this;

	AnimatorSceneryObject<AnimNodeDouble2D>::operator=(obj);

	return *this;
}