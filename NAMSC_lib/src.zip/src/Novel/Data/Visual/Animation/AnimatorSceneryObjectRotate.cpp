#pragma once
#include "Novel/Data/Visual/Animation/AnimatorSceneryObject.h"

/// Does the maths behind Rotate Animation
class AnimatorSceneryObjectRotate final : public AnimatorSceneryObject<AnimNodeDouble1D>
{
public:
	AnimatorSceneryObjectRotate() noexcept = default;
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed 
	AnimatorSceneryObjectRotate(SceneryObject* sceneryObject, AssetAnim<AnimNodeDouble1D>* assetAnim, uint startTime, double speed, int timesPlayed);
	AnimatorSceneryObjectRotate(const AnimatorSceneryObjectRotate& obj) noexcept { *this = obj; }
	AnimatorSceneryObjectRotate& operator=(const AnimatorSceneryObjectRotate& obj) noexcept;

	/// Changes colors of the SceneryObject
	void update() override;
	
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::AnimatorSceneryObjectRotate; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
};




inline AnimatorSceneryObjectRotate::AnimatorSceneryObjectRotate(SceneryObject* sceneryObject, AssetAnim<AnimNodeDouble1D>* assetAnim, uint startTime, double speed, int timesPlayed)
	: AnimatorSceneryObject<AnimNodeDouble1D>(startTime, speed, timesPlayed, sceneryObjectName)
{
	assetAnim_ = AssetManager::getInstance().findAssetAnimRotate(assetAnimName);
}

inline AnimatorSceneryObjectRotate& AnimatorSceneryObjectRotate::operator=(const AnimatorSceneryObjectRotate& obj) noexcept
{
	if (this == &obj) return *this;

	AnimatorSceneryObject<AnimNodeDouble1D>::operator=(obj);

	return *this;
}
