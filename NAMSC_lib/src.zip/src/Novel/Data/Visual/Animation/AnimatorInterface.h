#pragma once
#include "Novel/Data/NovelFlowInterface.h"

#include <QTimer>

/// More abstract Interface that allows to call `void run()` and `void update()` (inherited from NovelFlowInterface) regardless of the template arguments
class AnimatorInterface : public NovelFlowInterface
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream& dataStream, AnimatorInterface&);
	friend QDataStream& operator<<(QDataStream& dataStream, const AnimatorInterface&);
public:
	AnimatorInterface() noexcept = default;
	AnimatorInterface(const QString& assetAnimName_, const uint startDelay, const double speed, const int timesPlayed);
	AnimatorInterface(const AnimatorInterface& obj) = delete;
	AnimatorInterface& operator=(const AnimatorInterface& obj) noexcept;	
	// The destructor needs to be virtual, so the proper destructor will always be called when destroying an AnimatorInterface pointer
	virtual ~AnimatorInterface() noexcept = default;

	virtual bool checkForErrors(bool bComprehensive = false) const override = 0;

	/// Starts the Animation after `startDelay` milliseconds
	virtual void run() override { ensureResourcesAreLoaded(); QTimer::singleShot(startDelay, [&] { startAnimating(); }); }
	virtual void end() override {}

	// Must be called after the Save is loaded
	virtual void syncWithSave() override {}

protected:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	virtual NovelLib::SerializationID getType() const = 0;

	virtual void startAnimating()                     = 0;

	virtual void ensureResourcesAreLoaded()           = 0;

	/// Delay in milliseconds before the Animation will be played, allows for queueing Animations
	uint startDelay = 0;

	double speed    = 1.0;

	/// If set to -1, it will be looped infinitely
	int	timesPlayed = 1;

	/// Allows to calculate the elapsed time from the Animation start
	QTimer startTimer_;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline AnimatorInterface::AnimatorInterface(const QString& assetAnimName_, const uint startDelay, const double speed, const int timesPlayed)
	: startDelay(startDelay), speed(speed), timesPlayed(timesPlayed)
{
}

inline AnimatorInterface& AnimatorInterface::operator=(const AnimatorInterface& obj) noexcept
{
	if (this == &obj) return *this;

	startDelay  = obj.startDelay;
	speed       = obj.speed;
	timesPlayed = obj.timesPlayed;

	return *this;
}