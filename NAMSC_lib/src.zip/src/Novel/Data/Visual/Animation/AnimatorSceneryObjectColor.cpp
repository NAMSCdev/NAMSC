#pragma once
#include "Novel/Data/Visual/Animation/AnimatorSceneryObject.h"

/// Performs a Color Animation on a SceneryObject
class AnimatorSceneryObjectColor final : public AnimatorSceneryObject<AnimNodeDouble4D>
{
public:
	AnimatorSceneryObjectColor() noexcept = default;
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed 
	AnimatorSceneryObjectColor(SceneryObject* sceneryObject, AssetAnim<AnimNodeDouble4D>* assetAnim, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd);
	AnimatorSceneryObjectColor(const AnimatorSceneryObjectColor& obj) noexcept { *this = obj; }
	AnimatorSceneryObjectColor& operator=(const AnimatorSceneryObjectColor& obj) noexcept;

	/// Changes colors of the SceneryObject
	void update() override;

	/// \exception Error The
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::AnimatorSceneryObjectColor; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
};




inline AnimatorSceneryObjectColor::AnimatorSceneryObjectColor(SceneryObject* sceneryObject, AssetAnim<AnimNodeDouble4D>* assetAnim, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd)
	: AnimatorSceneryObject<AnimNodeDouble4D>(sceneryObject, assetAnim, startDelay, speed, timesPlayed, bStopAnimationAtEventEnd)
{
}

inline AnimatorSceneryObjectColor& AnimatorSceneryObjectColor::operator=(const AnimatorSceneryObjectColor& obj) noexcept
{
	if (this == &obj) return *this;

	AnimatorSceneryObject<AnimNodeDouble4D>::operator=(obj);

	return *this;
}
