#pragma once
#include "Novel/Data/NovelFlowInterface.h"

#include <QTimer>

/// More abstract Interface that allows to call `void run()` and `void update()` (inherited from NovelFlowInterface) regardless of the template arguments
class AnimatorInterface : public NovelFlowInterface
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream& dataStream, AnimatorInterface&);
	friend QDataStream& operator<<(QDataStream& dataStream, const AnimatorInterface&);
public:
	AnimatorInterface() noexcept = default;
	AnimatorInterface(const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed);
	AnimatorInterface(const AnimatorInterface& obj) noexcept { *this = obj; }
	AnimatorInterface& operator=(const AnimatorInterface& obj) noexcept;
	
	// The destructor needs to be virtual, so the proper destructor will always be called when destroying an AnimatorInterface pointer
	virtual ~AnimatorInterface() noexcept = default;

	/// Starts the Animation
	virtual void run() override { ensureResourcesAreLoaded(); QTimer::singleShot(startDelay_, [&] { startAnimating(); }); }

	// Must be called after the Save is loaded
	virtual void syncWithSave() override {}

	virtual bool checkForErrors(bool bComprehensive = false) const override = 0;

	virtual void end() override {}

protected:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	virtual NovelLib::SerializationID getType() const = 0;

	/// Marks the time point from which the Animation begins
	virtual void startAnimating() = 0;

	/// Ensures that the AnimAsset has its resources loaded
	virtual void ensureResourcesAreLoaded() = 0;

	/// Time in milliseconds of wait before the Animation will be played
	uint startDelay_       = 0;

	/// Allows to calculate the elapsed time from the Animation start
	QTimer startTimer_;

	double speed_          = 1.0;

	/// If set to -1, it will be looped infinitely
	int	timesPlayed_       = 1;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline AnimatorInterface::AnimatorInterface(const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed)
	: startDelay_(startDelay), speed_(speed), timesPlayed_(timesPlayed)
{
}

inline AnimatorInterface& AnimatorInterface::operator=(const AnimatorInterface& obj) noexcept
{
	if (this == &obj) return *this;

	startDelay_    = obj.startDelay_;
	startTime_     = obj.startTime_;
	speed_         = obj.speed_;
	timesPlayed_   = obj.timesPlayed_;
	assetAnimName_ = obj.assetAnimName_;

	return *this;
}