#pragma once

#include <QDataStream>

enum class AnimNodeType
{
	Unknown,
	Double,
	LongLong
};

/// Base class for an Animation Node 
struct AnimNodeBase
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream& dataStream, AnimNodeBase& t);
	friend QDataStream& operator<<(QDataStream& dataStream, const AnimNodeBase& t);

	bool operator<(const AnimNodeBase& rhs);

	/// Time point (in milliseconds) when the Animation will achieve this Node's state
	uint timeStamp;

	enum class AnimInterpolationMethod
	{
		Linear,
		Exponential,	//[optional]
		Hyperbolic		//[optional]
	} interpolationMethod;

protected:
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};

/// Animation Node, which state is an array of `double`
template<uint dimension>
struct AnimNodeDouble final : public AnimNodeBase
{
	/// This state will be reached exactly at [timestamp] time point
	double state_[dimension];

private:
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};

/// Animation Node, which state is an array of `double`
template<uint dimension>
struct AnimNodeLongLong final : public AnimNodeBase
{
	/// This state will be reached exactly at [timestamp] time point
	long long state_[dimension];

private:
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const override;
};

using AnimNodeDouble1D = AnimNodeDouble<1>;
using AnimNodeDouble2D = AnimNodeDouble<2>;
using AnimNodeDouble3D = AnimNodeDouble<3>;
using AnimNodeDouble4D = AnimNodeDouble<4>;

using AnimNodeLongLong1D = AnimNodeLongLong<1>;
using AnimNodeLongLong2D = AnimNodeLongLong<2>;
using AnimNodeLongLong3D = AnimNodeLongLong<3>;
using AnimNodeLongLong4D = AnimNodeLongLong<4>;




inline bool AnimNodeBase::operator<(const AnimNodeBase& rhs)
{
	return timeStamp < rhs.timeStamp;
}