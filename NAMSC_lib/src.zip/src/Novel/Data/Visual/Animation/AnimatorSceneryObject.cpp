#pragma once
#include "Novel/Data/Visual/Animation/AnimatorBase.h"
#include "Novel/Data/Visual/Animation/AnimatorSceneryObjectInterface.h"

//Performs an Animation on a SceneryObject
template<typename AnimNode>
class AnimatorSceneryObject : public AnimatorBase<AnimNode>, public AnimatorSceneryObjectInterface
{
public:
	AnimatorSceneryObject() noexcept = default;
	AnimatorSceneryObject(SceneryObject* const sceneryObject, AssetAnim<AnimNode>* const assetAnim, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd);
	AnimatorSceneryObject(const AnimatorSceneryObject<AnimNode>& obj) noexcept { *this = obj; }
	AnimatorSceneryObject<AnimNode>& operator=(const AnimatorSceneryObject<AnimNode>& obj);

	void startAnimating() override;

protected:
	/// Ensures that the AnimatorSceneryObject has its resources loaded
	void ensureResourcesAreLoaded() override;
};




template<typename AnimNode>
inline AnimatorSceneryObject<AnimNode>::AnimatorSceneryObject(SceneryObject* const sceneryObject, AssetAnim<AnimNode>* const assetAnim, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd) :
	AnimatorSceneryObjectInterface(sceneryObject, assetAnim, startDelay, speed, timesPlayed)
{
}

template<typename AnimNode>
inline AnimatorSceneryObject<AnimNode>& AnimatorSceneryObject<AnimNode>::operator=(const AnimatorSceneryObject<AnimNode>& obj)
{
	if (this == &obj) return *this;

	AnimatorSceneryObjectInterface::operator=(obj);
	AnimatorBase<AnimNode>::operator=(obj);

	return *this;
}

template<typename AnimNode>
inline void AnimatorSceneryObject<AnimNode>::ensureResourcesAreLoaded() 
{ 
	AnimatorSceneryObjectInterface::ensureResourcesAreLoaded();

	if (!AnimatorSceneryObject<AnimNode>::assetAnim_->isLoaded())
		AnimatorSceneryObject<AnimNode>::assetAnim_->load();

	AnimatorSceneryObject<AnimNode>::nodes_ = AnimatorSceneryObject<AnimNode>::assetAnim_->getAnimNodes();
}