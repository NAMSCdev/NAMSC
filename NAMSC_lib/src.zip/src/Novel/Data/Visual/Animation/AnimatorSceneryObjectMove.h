#pragma once
#include "Novel/Data/Visual/Animation/AnimatorSceneryObject.h"

/// Does the maths behind Move Animation
class AnimatorSceneryObjectMove final : public AnimatorSceneryObject<AnimNodeDouble2D>
{
public:
	AnimatorSceneryObjectMove() noexcept = default;
	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed 
	AnimatorSceneryObjectMove(SceneryObject* const sceneryObject, AssetAnim<AnimNodeDouble2D>* const assetAnim, const uint startDelay, const double speed, const int timesPlayed);
	AnimatorSceneryObjectMove(const AnimatorSceneryObjectMove& obj) = delete;
	AnimatorSceneryObjectMove& operator=(const AnimatorSceneryObjectMove& obj) noexcept;

	/// Changes colors of the SceneryObject
	void update() override;

	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const override;

private:
	/// Needed for Serialization, to know the class of an object about to be Serialization loaded
	/// \return NovelLib::SerializationID corresponding to the class of a serialized object
	NovelLib::SerializationID getType() const override { return NovelLib::SerializationID::AnimatorSceneryObjectMove; }

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream) override;
};




inline AnimatorSceneryObjectMove::AnimatorSceneryObjectMove(SceneryObject* const sceneryObject, AssetAnim<AnimNodeDouble2D>* const assetAnim, const uint startDelay, const double speed, const int timesPlayed) 
	: AnimatorSceneryObject<AnimNodeDouble2D>(sceneryObject, assetAnim, startDelay, speed, timesPlayed)
{
}

inline AnimatorSceneryObjectMove& AnimatorSceneryObjectMove::operator=(const AnimatorSceneryObjectMove& obj) noexcept
{
	if (this == &obj) return *this;

	AnimatorSceneryObject<AnimNodeDouble2D>::operator=(obj);

	return *this;
}

