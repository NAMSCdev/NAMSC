#pragma once
#include "Novel/Data/Visual/Animation/AnimatorInterface.h"

#include "Novel/Data/Visual/Scenery/SceneryObject.h"

#include "Serialization.h"

/// An Interface that allows to call `void run()` and `void update()` (inherited from NovelFlowInterface) regardless of the template arguments
/// Performs operations on a SceneryObject
class AnimatorSceneryObjectInterface : public AnimatorInterface
{
public:
	AnimatorSceneryObjectInterface() noexcept = default;
	AnimatorSceneryObjectInterface(const QString& sceneryObjectName, const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnd);
	AnimatorSceneryObjectInterface(const AnimatorSceneryObjectInterface& obj) noexcept { *this = obj; }
	AnimatorSceneryObjectInterface& operator=(const AnimatorSceneryObjectInterface& obj) noexcept;

	/// \exception Error A detailed Exception is thrown, if the proper QtMessageHandler is installed
	/// \return Whether an Error has occurred
	virtual bool checkForErrors(bool bComprehensive = false) const override;

protected:
	/// Scenery Object that will be affected by this Animator
	SceneryObject* sceneryObject_;

	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream) override;
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const override;
};




inline AnimatorSceneryObjectInterface::AnimatorSceneryObjectInterface(const QString& sceneryObjectName, const QString& assetAnimName, const uint startDelay, const double speed, const int timesPlayed, const bool bStopAnimationAtEventEnde) :
	AnimatorInterface(startDelay, speed, timesPlayed, assetAnimName), sceneryObjectName_(sceneryObjectName)
{
}

inline AnimatorSceneryObjectInterface& AnimatorSceneryObjectInterface::operator=(const AnimatorSceneryObjectInterface& obj) noexcept
{
	if (this == &obj) return *this;

	AnimatorInterface::operator=(obj);
	sceneryObjectName_ = obj.sceneryObjectName_;
	sceneryObject_     = obj.sceneryObject_;

	return *this;
}