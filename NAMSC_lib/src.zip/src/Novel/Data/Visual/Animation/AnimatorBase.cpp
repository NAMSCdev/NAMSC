#pragma once

#include <QList>

/// Controls an Animation output that will be assigned to change something that is being animated
template<typename AnimNode>
class AnimatorBase
{
public:
	/// The destructor needs to be virtual, so the proper destructor will always be called when destroying an AnimatorBase pointer
	virtual ~AnimatorBase() = 0;
	AnimatorBase<AnimNode>& operator=(const AnimatorBase<AnimNode>& obj);

protected:
	/// Calculates interpolated state from time that passed after `void startAnimating()`
	AnimNode currentAnimState();

	/// Points to the list of AnimNodes from an AssetAnim, which contain sequential changes that happen during the Animation
	QList<AnimNode>* nodes_;
	/// `nodes` multiplied by the Animation speed, so we don't need to waste CPU clocks every `AnimNode currentAnimState()`
	/// The initial state is added as the first Node, unless there is an AnimNode with `startDelay = 0` 
	/// \todo check if the first Node is necessary to be added
	QList<AnimNode>* adjustedNodes_;

	AssetAnim<AnimNode>* assetAnim_;

	/// Nodes containing current state and next state that we interpolate into
	QList<AnimNode>::const_iterator currentNode_,
									nextNode_;
};




template<typename AnimNode>
inline AnimatorBase<AnimNode>::~Animator() = default;

template<typename AnimNode>
inline AnimatorBase<AnimNode>& AnimatorBase<AnimNode>::operator=(const AnimatorBase<AnimNode>& obj)
{
	if (this == &obj) return *this;

	nodes_         = obj.nodes_;
	adjustedNodes_ = obj.adjustedNodes_;
	assetAnim_     = obj.assetAnim_;
	currentNode_   = nodes->cbegin() + (obj.currentNode - obj.nodes->cbegin());
	nextNode_      = currentNode_ + 1;

	return *this;
}