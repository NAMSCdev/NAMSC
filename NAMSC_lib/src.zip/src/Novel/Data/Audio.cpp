#pragma once
#include "Novel/Data/Audio/MusicPlaylist.h"

#include <QMediaPlayer>
#include <random>

const QString MusicPlaylist::nextSong()
{
	if (!audioFilesPaths_.size())
		return "";
	if (++currentlyPlayed_ > audioFilesPaths_.size())
	{
		if (bRandom_ && audioFilesPaths_.size() > 1)
		{
			QString previous = audioFilesPaths_[(currentlyPlayed_ == 0) ? (audioFilesPaths_.size() - 1) : (currentlyPlayed_ - 1)];
			std::random_device randomDevice;
			std::mt19937 generator(randomDevice());
			do
				std::shuffle(audioFilesPaths_.begin(), audioFilesPaths_.end(), generator);
			while (audioFilesPaths_[0] == previous);
		}
		currentlyPlayed_ = 0;
	}
	else if (!bPlayAtLeastOnce_ && bRandom_)
	{
		QString previous = audioFilesPaths_[(currentlyPlayed_ == 0) ? (audioFilesPaths_.size() - 1) : (currentlyPlayed_ - 1)];
		std::random_device randomDevice;
		std::mt19937 generator(randomDevice());
		do
			std::shuffle(audioFilesPaths_.begin(), audioFilesPaths_.end(), generator);
		while (audioFilesPaths_[currentlyPlayed_] == previous);
	}
	return audioFilesPaths_[currentlyPlayed_];
}