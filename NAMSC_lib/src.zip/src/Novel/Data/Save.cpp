#include "Novel/Data/Novel.h"

NovelState* NovelState::getCurrentlyLoadedState() 
{
	return &(Novel::getInstance().state_); 
}

void NovelState::addAnimator(AnimatorSceneryObjectInterface* animator)
{
	scenery.addAnimator(animator);
}
