//#include "Novel/Data/Novel.h"
#include "Novel/Data/Scene.h"
#include "Novel/Data/Save/NovelState.h"

bool Novel::checkForErrors(bool bComprehensive = false) const
{
	for (const Scene& scene : scenes_)
		if (scene.checkForErrors(bComprehensive))
			return true;
	return false;
}

void Novel::run()
{
	if (state.sceneID >= scenes_.size())
		//todo: exception
		;
	scenes_[state.sceneID].run();
}

void Novel::update()
{
	scenes_[state.sceneID].update();
}
void Novel::end() {}

void Novel::syncWithSave()
{
	for (Scene& scene : scenes_)
		scene.syncWithSave();
}

/// Creates new NovelState and loads it into the SaveSlot
void newState(uint slot)
{
	state.createNew(slot);
}
/// Loads player's NovelState from a SaveFile in the given SaveSlot
bool loadState(uint slot);
/// Saves player's NovelState to a SaveFile in the given SaveSlot
void saveState(uint slot);