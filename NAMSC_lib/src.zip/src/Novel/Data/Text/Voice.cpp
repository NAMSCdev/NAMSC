#pragma once

#include <QColor>
#include <QFont>

#include "Novel/Data/Audio/Sound.h"
#include "Novel/Data/Asset/AssetManager.h"

/// Tells how the text should be displayed
/// [optional] And if there should be any lip syncing done (if the Character is Live2D compatible)
class Voice
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Voice&);
	friend QDataStream& operator<<(QDataStream&, const Voice&);
public:
	/// [optional] If a Character is compatible with Live2D, we can animate its lips while they are talking
	enum class LipSyncType
	{
		None,		/// No animation
		Full,		/// Animation even if the sound is not produced (synthe
		Static		/// Open mouth while talking regardless of the sound volume, but no animation
	};

	Voice() noexcept = default;
	Voice(const QString& name, const QString& fontName, const uint fontSize, const bool bold, const bool italic, const bool underscore, const QColor color, const double cpsMultiplier = 1.0, const uint cpsOverwrite = 0, const Qt::AlignmentFlag alignment = Qt::AlignHCenter, const LipSyncType lipSync = LipSyncType::None) noexcept;
	Voice(const Voice& obj) = delete;
	Voice& operator=(const Voice& obj) noexcept;

	QString name;

private:

	QFont font_;
	uint fontSize_        = 12;

	/// [optional] A short Sound played after a single character insertion
	/// It is cut short if a new character appears before the Sound finished playing
	/// Once this is set, the cps should also be set to a customized for best experience
	//Sound insertionSound;

	/// Wraps the rich text with a <b> tag, bolding it
	bool bold_            = false;

	/// Wraps the rich text with a <i> tag, initializing it
	bool italic_          = false;

	/// Wraps the rich text with a <u> tag, underscoring it
	bool underscore_      = false;

	/// Multiplies `NovelSettings::cps` setting
	double cpsMultiplier_ = 1.0;

	/// Overwrites `NovelSettings::cps` setting
	/// 0 stands for unchanged (changed only by `cpsMultiplier`)
	/// When `cpsOverwrite` is set, `cpsMultiplier`no longer has any effect on Characters Per Second
	uint cpsOverwrite_    = 0;

	/// Default color in RGBA format used to display the text spoken by this Voice
	QColor color_         = { 0, 0, 0, 255 };

	/// [optional] Alignment of the text
	Qt::AlignmentFlag alignment_ = Qt::AlignHCenter;

	/// [optional] If a Character is compatible with Live2D, we can animate its lips while they are talking
	/// Possible values:
	/// - None
	/// - Full
	/// - Static
	LipSyncType lipSync_ = LipSyncType::Full;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline Voice::Voice(const QString& name, const QString& fontName, const uint fontSize, const bool bold, const bool italic, const bool underscore, const QColor color, const double cpsMultiplier, const uint cpsOverwrite, const Qt::AlignmentFlag alignment, const LipSyncType lipSync) noexcept
	: name(name), fontSize_(fontSize), bold_(bold), italic_(italic), underscore_(underscore),
	color_(color), cpsOverwrite_(cpsOverwrite), alignment_(alignment), lipSync_(lipSync)
{
	font_ = QFont(fontName, fontSize_);
}

inline Voice& Voice::operator=(const Voice& obj) noexcept
{
	if (this == &obj) return *this;

	name		   = obj.name;
	font_          = obj.font_;
	fontSize_      = obj.fontSize_;
	bold_          = obj.bold_;
	italic_        = obj.italic_;
	underscore_    = obj.underscore_;
	cpsMultiplier_ = obj.cpsMultiplier_;
	cpsOverwrite_  = obj.cpsOverwrite_;
	color_         = obj.color_;
	alignment_     = obj.alignment_;
	lipSync_       = obj.lipSync_;

	return *this;
}