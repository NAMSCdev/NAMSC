#include "Novel/Data/Text/Choice.h"

Choice::Choice(const QString& name, const Translation& text, const QString& condition, const int jumpSceneID, const ChoiceDisplayOptions& choiceDisplayOptions)
	: name(name), text(text), condition(condition), jumpSceneID(jumpSceneID), choiceDisplayOptions(choiceDisplayOptions)
{
}

Choice::ChoiceDisplayOptions::ChoiceDisplayOptions(const QString& fontName, const uint fontSize, const bool bHideIfConditionNotMet)
	: fontName(fontName), fontSize(fontSize), bHideIfConditionNotMet(bHideIfConditionNotMet)
{
	font = QFont(fontName);
}

Choice& Choice::operator=(const Choice& obj)
{
	if (this == &obj) return *this;

	onRun_               = obj.onRun_;
	name                 = obj.name;
	text                 = obj.text;
	condition            = obj.condition;
	jumpSceneID          = obj.jumpSceneID;
	choiceDisplayOptions = obj.choiceDisplayOptions;

	return *this;
}

Choice::ChoiceDisplayOptions& Choice::ChoiceDisplayOptions::operator=(const ChoiceDisplayOptions& obj)
{
	if (this == &obj) return *this;

	fontName               = obj.fontName;
	font                   = obj.font;
	fontSize               = obj.fontSize;
	bHideIfConditionNotMet = obj.bHideIfConditionNotMet;

	return *this;
}

void Choice::serializableLoad(QDataStream& dataStream)
{
	dataStream >> name >> text >> condition >> jumpSceneID >> choiceDisplayOptions;
}

void Choice::serializableSave(QDataStream& dataStream) const
{
	dataStream << name << text << condition << jumpSceneID << choiceDisplayOptions;
}

void Choice::ChoiceDisplayOptions::serializableLoad(QDataStream& dataStream)
{
	dataStream >> fontName >> fontSize >> bHideIfConditionNotMet;
}

void Choice::ChoiceDisplayOptions::serializableSave(QDataStream& dataStream) const
{
	dataStream << fontName << fontSize << bHideIfConditionNotMet;
}