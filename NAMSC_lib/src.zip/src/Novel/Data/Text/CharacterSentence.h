#pragma once
#include "Novel/Data/Text/Sentence.h"

/// Represents one portion of the Dialogue spoken by a Character that ends with user click if `bEndWithInput_` is enabled or after `waitBeforeContinueTime_` milliseconds
/// This could be not only one sentence but also a longer text, but this name is kind of intuitional
class CharacterSentence final : public Sentence
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Sentence&);
	friend QDataStream& operator<<(QDataStream&, const Sentence&);
public:

	/// [optional] Flags (they can be joined) that specify effect that appearing words have, if `wordAppearType_ == WordAppearType::WordByWord`
	/// NOTE: RenPy doesn't support this by default (other than manual usage of Python), so integration with it would be hard
	/// It is probably better to contribute to RenPy by adding this feature and then adding support for RenPy for it there
	enum class SentenceStyle
	{
		Bold		= 0b1,			
		Italic		= 0b10,	
		Underscore	= 0b100,
		Color		= 0b1000		/// Custom color
	};

	CharacterSentence() noexcept = default;
	CharacterSentence(const Translation& content, const QString& voiceName_, const uint cpsOverwrite, const bool bEndWithInput, const double waitBeforeContinueTime);
	CharacterSentence(const Sentence& obj) = delete;
	CharacterSentence& operator=(const Sentence& obj) noexcept;


private:
	/// A temporary Image to show some facial expresions or anything else
	/// Empty means no change
	QString     assetImageName_ = "";
	AssetImage* assetImage_     = nullptr;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};