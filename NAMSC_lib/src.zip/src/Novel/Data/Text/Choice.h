#pragma once

#include <QFont>

#include "Novel/Data/Text/Translation.h"
#include "Novel/Event/EventJump.h"
#include "Serialization.h"

class Choice
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Choice&);
	friend QDataStream& operator<<(QDataStream&, const Choice&);
	struct ChoiceDisplayOptions;
public:
	Choice() noexcept = default;
	Choice(const QString& name, const Translation& text, const QString& condition, const int jumpSceneID, const ChoiceDisplayOptions& displayOptions);
	Choice(const Choice& obj) noexcept { *this = obj; }
	Choice& operator=(const Choice& obj) noexcept;

	void run();

	/// Sets a function pointer that is called (if not nullptr) after the Choice's `void run()` allowing for data read
	void setOnRunListener(std::function<void(const QString name, const Translation* text, const QString condition, const int jumpSceneID)> onRun) { onRun_ = onRun; }

	QString name = "";

	/// The text that is displayed as a Choice for the player
	Translation text;

	/// Logical condition that needs to be fulfilled in order for this Choice to be available
	QString condition = "";

	/// If the player chooses this Choice, they will jump to this Scene
	int jumpSceneID = -1;

	/// [optional] 
	struct ChoiceDisplayOptions
	{
		//Friends for serialization
		friend QDataStream& operator>>(QDataStream&, ChoiceDisplayOptions&);
		friend QDataStream& operator<<(QDataStream&, const ChoiceDisplayOptions&);

		ChoiceDisplayOptions() noexcept = default;
		ChoiceDisplayOptions(const QString& fontName, const uint fontSize, const bool bHideIfConditionNotMet);
		ChoiceDisplayOptions(const ChoiceDisplayOptions& obj) noexcept { *this = obj; }
		ChoiceDisplayOptions& operator=(const ChoiceDisplayOptions& obj) noexcept;

		QString fontName;
		QFont   font;
		uint    fontSize;

		/// Normally, if the Choice is not available, it will be greyed out, setting this to [true] will make the Choice not appear at all
		bool bHideIfConditionNotMet;

	private:
		//---SERIALIZATION---
		/// Loading an object from a binary file
		/// \param dataStream Stream (presumably connected to a QFile) to read from
		void serializableLoad(QDataStream& dataStream);
		/// Saving an object to a binary file
		/// \param dataStream Stream (presumably connected to a QFile) to save to
		void serializableSave(QDataStream& dataStream) const;
	} choiceDisplayOptions;

private:
	std::function<void(const QString name, const Translation* text, const QString condition, const int jumpSceneID)> onRun_ = nullptr;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};