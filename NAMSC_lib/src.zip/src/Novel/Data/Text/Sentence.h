#pragma once

#include "Novel/Data/Text/Translation.h"
#include "Novel/Data/Text/Voice.h"

/// Represents one portion of the Dialogue that ends with user click if `bEndWithInput_` is enabled or after `waitBeforeContinueTime_` milliseconds
/// This could be not only one sentence but also a longer text, but this name is kind of intuitional
class Sentence
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Sentence&);
	friend QDataStream& operator<<(QDataStream&, const Sentence&);
public:
	/// Determines how the text should appear
	enum class SentenceAppearType
	{
		CharByChar,		/// It gives a feeling of actual talking and it is possible to change character insertion sound (if Character is mute) and speed
		WordByWord		/// [optional] Karaoke-like style, where words appear one after another
	};

	/// [optional] Flags (they can be joined) that specify effect that appearing words have, if `wordAppearType_ == WordAppearType::WordByWord`
	/// NOTE: RenPy doesn't support this by default (other than manual usage of Python), so integration with it would be hard
	/// It is probably better to contribute to RenPy by adding this feature and then adding support for RenPy for it there
	enum class SentenceStyle
	{
		Bold		= 0b1,			
		Italic		= 0b10,	
		Underscore	= 0b100,
		Color		= 0b1000		/// Custom color
	};

	Sentence() noexcept = default;
	Sentence(const Translation& content, const QString& voiceName_, const uint cpsOverwrite, const bool bEndWithInput, const double waitBeforeContinueTime);
	Sentence(const Sentence& obj) = delete;
	Sentence& operator=(const Sentence& obj) noexcept;

	/// Things to be said, in the chosen language in NovelSettings
	Translation content;

	/// The speaking Character's displayed name
	QString displayedName = "";

	/// Multiplies `NovelSettings::cps_` setting, unless `cpsOverwrite_` is set
	/// If the Sentence is spoken by a Voice with its own `cpsMultiplier_`, they multiply
	double cpsMultiplier_ = 1.0;

	/// Overwrites `NovelSettings::cps_` setting
	/// 0 stands for unchanged (changed only by `cpsMultiplier_`)
	/// When `cpsOverwrite` is set, `cpsMultiplier_` no longer has any effect on Characters Per Second
	uint cpsOverwrite_ = 0;

	/// Whether the user `Qt::MouseButton::LeftButton` (if `NovelSettings::mouseButton_` is `true`) / `NovelSettings::nextButton_` is needed to end the Sentence
	bool bEndWithInput_ = true;

	/// If the `bEndWithInput_` is set to false, this is the time in milliseconds that the Engine will wait after the text is rendered before moving to a new Sentence
	uint waitBeforeContinueTime_ = 1000;

private:
	QString    characterName = "";
	Character* character = nullptr;

	QString	voiceName_;
	Voice* voice_;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline Sentence& Sentence::operator=(const Sentence& obj) noexcept
{
	if (this == &obj) return *this;

	content_                = obj.content_;
	voiceName_              = obj.voiceName_;
	voice_                  = obj.voice_;
	cpsOverwrite_           = obj.cpsOverwrite_;
	bEndWithInput_          = obj.bEndWithInput_;
	waitBeforeContinueTime_ = obj.waitBeforeContinueTime_;

	return *this;
}