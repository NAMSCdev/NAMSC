#include "Novel/Data/Text/Sentence.h"


inline Sentence& Sentence::operator=(const Sentence& obj) noexcept
{
	if (this == &obj) return *this;

	content_                = obj.content_;
	voiceName_              = obj.voiceName_;
	voice_                  = obj.voice_;
	cpsOverwrite_           = obj.cpsOverwrite_;
	bEndWithInput_          = obj.bEndWithInput_;
	waitBeforeContinueTime_ = obj.waitBeforeContinueTime_;

	return *this;
}

void Sentence::serializableLoad(QDataStream& dataStream)
{
	dataStream >> content_ >> voiceName_ >> cpsOverwrite_ >> bEndWithInput_ >> waitBeforeContinueTime_;

	voice_ = Novel::getInstance().findVoice(voiceName_);
}

void Sentence::serializableSave(QDataStream& dataStream) const
{
	dataStream << NovelLib::SerializationID::Sentence << content_ << voiceName_ << cpsOverwrite_ << bEndWithInput_ << waitBeforeContinueTime_;
}