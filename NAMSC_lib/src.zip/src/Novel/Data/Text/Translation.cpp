#pragma once

#include <QMap>

#include "Novel/Data/Asset/AssetText.h"

/// Class representing every Speech that is to be spoken by a Character or Narrator
/// [optional] It also contains duration of every word if it's to be voiced/slowed down
class Translation
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Translation&);
	friend QDataStream& operator<<(QDataStream&, const Translation&);
public:
	Translation() noexcept = default;
	Translation(const QMap<QString, AssetText>& translations) noexcept;
	Translation(const Translation& obj) noexcept { *this = obj; }
	Translation& operator=(const Translation& obj) noexcept;

	/// Return the text in the given language
	/// \param language Returns text in this language, or if it doesn't have it - in default one (`NovelSettings::defaultLanguage`)
	/// \todo Read how to cleanly describe default params in Doxygen
	const QString text(const QString language = NovelSettings::getInstance().language_);

	/// Adds or replaces a Translation to the `translations` map
	/// \param language The language of the text to add/overwrite
	/// \param newText The text to add/overwrite
	void addTranslation(const QString& language, const QString& newText) { translations_[language].setText(newText); }

	/// Removes Ttranslation from `translations` list
	/// \param language The language of the Translation to be deleted
	void deleteTranslation(const QString& language);

	/// Changes default Language 
	/// If there is no translation for the new one, it is copied from previous 
	/// \param defaultLanguage Previous default language
	void changeDefaultLanguage(QString& oldDefaultLanguage);

	//[optional] Return word durations
	//const QList<uint>	durations();

private:
	/// Store text for different languages
	QMap<QString, AssetText> translations_;

	//[optional] Store word durations for [Sentence::WordAppearType::WordByWord] appear type for different languages
	//QMap<const QString, const QList<uint>>	wordDurations;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline Translation::Translation(const QMap<QString, AssetText>&& translations) noexcept:
	translations_(translations))
{
}

inline Translation& Translation::operator=(const Translation& obj) noexcept
{
	if (this == &obj) return *this;

	translations_ = obj.translations_;

	return *this;
}

inline void Translation::deleteTranslation(const QString& language)
{ 
	if (language == NovelSettings::getInstance().defaultLanguage_)
		qInfo() << "Tried to remove default language. The option to do so should not be allowed at all";

	translations_.remove(language);
}

inline void Translation::changeDefaultLanguage(QString& oldDefaultLanguage)
{
	if (translations_.contains(NovelSettings::getInstance().defaultLanguage_))
		return;

	qDebug() << "Copying old language File to the new language";

	if (oldDefaultLanguage == NovelSettings::getInstance().defaultLanguage_)
		qInfo() << "Tried to remove the default language. The option to do so should not be allowed at all";

	translations_.remove(oldDefaultLanguage);
}
