#pragma once

#include <QString>

/// [optional] The additonal label of a Scene, which allows us to put Scenes into easier managable bins
struct Chapter
{
    //Friends for serialization
    friend QDataStream& operator>>(QDataStream& dataStream, Chapter&);
    friend QDataStream& operator<<(QDataStream& dataStream, const Chapter&);

	/// Name that will be displayed in the Editor
	QString name;

private:
	/// Parent of the Chapter 
	Chapter* parent_ = nullptr;

    //---SERIALIZATION---
    /// Loading an object from a binary file
    /// \param dataStream Stream (presumably connected to a QFile) to read from
    void serializableLoad(QDataStream& dataStream);
    /// Saving an object to a binary file
    /// \param dataStream Stream (presumably connected to a QFile) to save to
    void serializableSave(QDataStream& dataStream) const;
};