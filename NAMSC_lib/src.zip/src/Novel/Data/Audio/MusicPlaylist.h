#pragma once

#include "Novel/Data/Audio/AudioSettings.h"
#include "Novel/Data/Asset/AssetManager.h"

class ActionVisitorCorrectMusicPlaylist;

/// List of Songs that can be played in the background
class MusicPlaylist 
{
	friend ActionVisitorCorrectMusicPlaylist;
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, MusicPlaylist&);
	friend QDataStream& operator<<(QDataStream&, const MusicPlaylist&);
public:
	MusicPlaylist() noexcept = default;
	/// \exception Error Couldn't find/read the Song files
	MusicPlaylist(const QList<QString>& songFilesPaths_, const bool bRandomizePlaylist_, const bool bPlayAtLeastOnce_, AudioSettings audioSettings);
	MusicPlaylist(const MusicPlaylist& obj) noexcept { *this = obj; }
	MusicPlaylist& operator=(const MusicPlaylist& obj) noexcept;
	bool operator==(const MusicPlaylist& obj) noexcept;
	bool operator!=(const MusicPlaylist& obj) noexcept;

	const QString nextSong();

	bool contains(const QString &song) { return songFilesPaths_.contains(song); }

	/// \exception Error Paths in `audioFilesPaths_` are invalid / some Songs cannot be read (whatever the reason)
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

	AudioSettings audioSettings;

private:
	QList<QString> songFilesPaths_;

	bool bRandomizePlaylist_ = false;

	/// [optional] Whether every Song should be played at least once before the playlist is shuffled again
	/// It doesn't mmake any sense unles `bRandomOrder_ = true`
	bool bPlayAtLeastOnce_ = false;

	int currentlyPlayedSongID_ = -1;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline MusicPlaylist::MusicPlaylist(const QList<QString>& songFilesPaths_, const bool bRandomizePlaylist_, const bool bPlayAtLeastOnce_, AudioSettings audioSettings)
	: songFilesPaths_(songFilesPaths_), bRandomizePlaylist_(bRandomizePlaylist_), bPlayAtLeastOnce_(bPlayAtLeastOnce_), audioSettings(audioSettings)
{
}

inline MusicPlaylist& MusicPlaylist::operator=(const MusicPlaylist& obj) noexcept
{
	if (this == &obj) return *this;

	audioSettings          = obj.audioSettings;
	songFilesPaths_        = obj.songFilesPaths_;
	bRandomizePlaylist_    = obj.bRandomizePlaylist_;
	bPlayAtLeastOnce_      = obj.bPlayAtLeastOnce_;
	currentlyPlayedSongID_ = obj.currentlyPlayedSongID_;

	return *this;
}