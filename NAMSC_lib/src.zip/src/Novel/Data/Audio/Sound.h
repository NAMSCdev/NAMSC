#pragma once
#include <QSoundEffect>

#include "Novel/Data/Audio/AudioSettings.h"

class ActionVisitorCorrectSounds;

/// Holds data for QSoundEffect, to play some Sound
class Sound
{
	friend ActionVisitorCorrectSounds;
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, Sound&);
	friend QDataStream& operator<<(QDataStream&, const Sound&);
public:
	Sound() noexcept = default;
	/// \exception Error Couldn't find/read the `soundFile_`
	Sound(const QString& soundFile, const AudioSettings& audioSettings);
	Sound(Sound& obj) = delete;
	Sound& operator=(const Sound& obj) noexcept;

	/// \todo Set other Settings as well
	void load() { setSource(soundFile_); }

	bool isLoaded() const { return !source().isEmpty(); }

	/// \exception Error `soundFile_` is invalid / `soundFile_` content cannot be read (whatever the reason)
	/// \return Whether an Error has occurred
	bool checkForErrors(bool bComprehensive = false) const;

protected:
	QSoundEffect* qSoundEffect = nullptr;
	QString soundFile_;

	AudioSettings audioSettings_;

	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline Sound::Sound(const QString& soundFile, const AudioSettings& audioSettings) 
	: soundFile_(soundFile), audioSettings_(audioSettings)
{
	checkForErrors(true);
}

inline Sound& Sound::operator=(const Sound& obj) noexcept
{
	if (this == &obj) return *this;

	soundFile_     = obj.soundFile_;
	audioSettings_ = obj.audioSettings_;

	if (obj.isLoaded())
		load();

	return *this;
}