#pragma once
#include "Novel/Data/Audio/Sound.h"

/// A Sound that is meant to be played during an Event
class SoundEffect final : public Sound
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, SoundEffect&);
	friend QDataStream& operator<<(QDataStream&, const SoundEffect&);
public:
	SoundEffect() noexcept = default;
	/// \exception Error Couldn't find/read the SoundEffects' files
	SoundEffect(const QString& audioFile, const AudioSettings& settings, const uint startDelay, const bool bPersistToNewEvent);
	SoundEffect(SoundEffect& obj) = delete;
	SoundEffect& operator=(const SoundEffect& obj) noexcept;

private:
	uint startDelay = 0;

	/// Whether the SoundEffect should be cut if user gets to the next Scene's Event before this SoundEffect has ended playing
	bool bPersistToNewEvent_ = false;
	
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	void serializableSave(QDataStream& dataStream) const;
};




inline SoundEffect::SoundEffect(const QString& audioFile, const AudioSettings& settings, const uint startDelay, const bool bPersistToNewEvent) 
	: Sound(audioFile, settings), bPersistToNewEvent_(bPersistToNewEvent), startDelay(startDelay)
{
	checkForErrors(true);
}

inline SoundEffect& SoundEffect::operator=(const SoundEffect& obj)
{
	if (this == &obj) return *this;

	Sound::operator=(obj);
	bPersistToNewEvent_ = obj.bPersistToNewEvent_;
	startDelay         = obj.startDelay;
	
	if (obj.isLoaded())
		load();

	return *this;
}