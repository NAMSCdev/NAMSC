#pragma once
#include <QDataStream>

/// Common properties for Audio playing
class AudioSettings
{
	//Friends for serialization
	friend QDataStream& operator>>(QDataStream&, AudioSettings&);
	friend QDataStream& operator<<(QDataStream&, const AudioSettings&);
public:
	AudioSettings() noexcept = default;
	AudioSettings(double volume, double stereo, int timesPlayed, uint delayBetweenReplays) noexcept;
	AudioSettings(const AudioSettings& obj) noexcept { *this = obj; }
	AudioSettings& operator=(const AudioSettings& obj) noexcept;

	double volume_            = 1.0;

	/// How the Sound is played in the stereo headphones
	/// 0.0 - left only, 0.5 - both, 1.0 - right only
	/// Accepted values: 0.0 - 1.0
	/// \todo [optional] Allow more channels
	double stereo_            = 0.5;

	/// Can be set to -1, so it will be looped infinitely
	int	timesPlayed           = 1;

	/// How much time in millisecond passes before next repetition of this Audio
	uint delayBetweenReplays_ = 0;

private:
	//---SERIALIZATION---
	/// Loading an object from a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to read from
	virtual void serializableLoad(QDataStream& dataStream);
	/// Saving an object to a binary file
	/// \param dataStream Stream (presumably connected to a QFile) to save to
	virtual void serializableSave(QDataStream& dataStream) const;
};




inline AudioSettings::AudioSettings(double volume, double stereo, int timesPlayed, uint delayBetweenReplays) noexcept :
	volume_(volume), stereo_(stereo), timesPlayed(timesPlayed), delayBetweenReplays_(delayBetweenReplays)
{
}

inline AudioSettings& AudioSettings::operator=(const AudioSettings& obj) noexcept
{
	if (this == &obj) return *this;

	volume_              = obj.volume_;
	stereo_              = obj.stereo_;
	timesPlayed          = obj.timesPlayed;
	delayBetweenReplays_ = obj.delayBetweenReplays_;

	return *this;
}